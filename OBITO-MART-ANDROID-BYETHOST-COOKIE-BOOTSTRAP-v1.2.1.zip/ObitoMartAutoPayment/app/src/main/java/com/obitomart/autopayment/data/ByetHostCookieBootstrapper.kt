package com.obitomart.autopayment.data

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * Runs ByetHost's browser verification on the site's normal HTTPS homepage,
 * not on activate.php. The API GET endpoint intentionally returns JSON
 * "POST required" and therefore may never execute the browser challenge.
 * The WebView cookie jar is then copied to the native API client's Cookie header.
 */
internal object ByetHostCookieBootstrapper {
    fun obtain(context: Context, apiUrl: String, timeoutSeconds: Long = 35): String {
        val parsed = Uri.parse(apiUrl)
        val scheme = parsed.scheme ?: "https"
        val host = parsed.host ?: "obitomart.byethost8.com"
        val origin = "$scheme://$host/"
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)

        fun validCookie(): String {
            val value = cookieManager.getCookie(origin).orEmpty()
            return value.split(';').map { it.trim() }
                .filter { it.startsWith("__test=") && it.length > "__test=".length }
                .joinToString("; ")
        }

        validCookie().takeIf { it.isNotBlank() }?.let { return it }

        val latch = CountDownLatch(1)
        val result = AtomicReference("")
        val finished = AtomicBoolean(false)
        val webViewRef = AtomicReference<WebView?>(null)
        val main = Handler(Looper.getMainLooper())
        val deadline = System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(timeoutSeconds)

        val poll = object : Runnable {
            override fun run() {
                if (finished.get()) return
                cookieManager.flush()
                val cookie = validCookie()
                if (cookie.isNotBlank()) {
                    result.set(cookie)
                    if (finished.compareAndSet(false, true)) latch.countDown()
                } else if (System.currentTimeMillis() < deadline) {
                    main.postDelayed(this, 250)
                } else {
                    if (finished.compareAndSet(false, true)) latch.countDown()
                }
            }
        }

        main.post {
            try {
                val webView = WebView(context)
                webViewRef.set(webView)
                webView.settings.javaScriptEnabled = true
                webView.settings.domStorageEnabled = true
                webView.settings.javaScriptCanOpenWindowsAutomatically = false
                webView.settings.setSupportMultipleWindows(false)
                webView.webChromeClient = WebChromeClient()
                webView.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String) {
                        cookieManager.flush()
                        main.removeCallbacks(poll)
                        main.post(poll)
                    }
                }
                webView.loadUrl(origin)
                main.postDelayed(poll, 500)
            } catch (_: Throwable) {
                if (finished.compareAndSet(false, true)) latch.countDown()
            }
        }

        val completed = latch.await(timeoutSeconds + 5, TimeUnit.SECONDS)
        val cookie = result.get()
        main.post {
            main.removeCallbacks(poll)
            try {
                webViewRef.get()?.stopLoading()
                webViewRef.get()?.destroy()
            } catch (_: Throwable) { }
        }

        if (!completed || cookie.isBlank()) {
            throw IllegalStateException(
                "ByetHost browser verification cookie পাওয়া যায়নি। প্রথমে Chrome-এ https://obitomart.byethost8.com/ খুলে দেখুন; তারপর আবার চেষ্টা করুন। Hosting যদি native API traffic-এ challenge বাধ্যতামূলক করে, free plan-এ whitelist ছাড়া এটি সমাধান নাও হতে পারে।"
            )
        }
        return cookie
    }
}
