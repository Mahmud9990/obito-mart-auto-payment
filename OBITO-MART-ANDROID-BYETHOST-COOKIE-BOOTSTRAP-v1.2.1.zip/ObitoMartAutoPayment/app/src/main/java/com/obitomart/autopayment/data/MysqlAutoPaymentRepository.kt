package com.obitomart.autopayment.data

import android.content.Context
import com.obitomart.autopayment.model.*
import com.obitomart.autopayment.parser.PaymentMessageParser
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicInteger

/** Compatibility class name retained so existing screens/services keep compiling.
 * All networking in this implementation targets the OBITO MART PHP/MySQL API only.
 */
class MysqlAutoPaymentRepository(private val context: Context) {
    private val prefs = AutoPaymentPrefs(context)
    companion object {
        // Set this to the deployed OBITO MART domain before building the APK.
        const val API_BASE = "https://obitomart.byethost8.com/api/autopay/"
        private val detected = AtomicInteger(0)
        private val approved = AtomicInteger(0)
    }

    private fun request(path: String, body: JSONObject, authenticated: Boolean = true): JSONObject {
        val endpoint = API_BASE + path
        val url = URL(endpoint)
        val c = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 25000
            doOutput = true
            instanceFollowRedirects = false
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Cache-Control", "no-cache")
            setRequestProperty("User-Agent", "OBITO-MART-AutoPayment/1.1.1")
            if (prefs.byetHostCookie.isNotBlank()) {
                setRequestProperty("Cookie", prefs.byetHostCookie)
            }
        }

        if (authenticated) {
            body.put("deviceId", prefs.deviceId)
            body.put("deviceToken", prefs.sessionToken)
        }

        try {
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val contentType = c.contentType ?: "unknown"
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""

            val result = try {
                JSONObject(raw)
            } catch (_: Exception) {
                val preview = raw
                    .replace(Regex("(?is)<script.*?</script>"), " ")
                    .replace(Regex("(?is)<style.*?</style>"), " ")
                    .replace(Regex("<[^>]*>"), " ")
                    .replace(Regex("\\s+"), " ")
                    .trim()
                    .take(260)
                val detail = if (preview.isBlank()) "খালি response এসেছে" else preview
                throw IllegalStateException(
                    "API JSON নয় (HTTP $code, Content-Type: $contentType). " +
                    "URL: $endpoint. সার্ভার response: $detail"
                )
            }

            if (code !in 200..299 || !result.optBoolean("ok", false)) {
                val message = result.optString("error", "HTTP $code")
                val errorCode = result.optString("errorCode", "")
                throw IllegalStateException(
                    if (errorCode.isNotBlank()) "$message (HTTP $code, code $errorCode)"
                    else "$message (HTTP $code)"
                )
            }
            return result
        } finally {
            c.disconnect()
        }
    }

    fun activateWithKey(rawKey: String, deviceName: String): Pair<Boolean, String> = try {
        // Complete the browser challenge on the site homepage (the API GET
        // endpoint itself only returns {"error":"POST required"}).
        prefs.byetHostCookie = ByetHostCookieBootstrapper.obtain(
            context,
            API_BASE
        )
        val r = request("activate.php", JSONObject().put("activationKey", rawKey.trim())
            .put("deviceId", prefs.deviceId).put("deviceName", deviceName.ifBlank { prefs.deviceName }), false)
        prefs.activationKey = rawKey.trim().uppercase()
        prefs.sessionToken = r.getString("deviceToken")
        prefs.deviceStatus = "active"
        prefs.activationTimestamp = System.currentTimeMillis()
        Pair(true, "ডিভাইস MySQL AutoPay সার্ভারে সক্রিয় হয়েছে।")
    } catch (e: Exception) { Pair(false, e.message ?: "Activation failed") }

    fun checkDeviceSessionStatus(): String = try {
        request("heartbeat.php", JSONObject())
        prefs.deviceStatus = "active"; "active"
    } catch (_: Exception) { "offline" }

    fun updateHeartbeat(isActive: Boolean) { if (prefs.isDeviceActivated) try { request("heartbeat.php", JSONObject().put("monitoring", isActive)) } catch (_: Exception) {} }

    fun deactivateDevice() {
        try { request("revoke.php", JSONObject()) } catch (_: Exception) {}
        prefs.clearActivationSession()
    }

    fun syncDashboardMetrics(): Int = try {
        val r = request("dashboard.php", JSONObject())
        prefs.approvedCount = r.optInt("todayCount", 0)
        prefs.todayAmount = r.optDouble("todayAmount", 0.0)
        r.optInt("pendingCount", 0)
    } catch (_: Exception) { 0 }

    fun fetchPendingDepositsCount(): Int = syncDashboardMetrics()

    fun processIncomingPayment(parsed: ParsedPayment): PaymentLogEntry = synchronized(this) {
        detected.incrementAndGet()
        try {
            val event = JSONObject().put("method", parsed.method.id).put("txId", parsed.txIdNormalized)
                .put("amount", parsed.amount).put("senderNumber", parsed.senderNumber)
                .put("sourceType", parsed.sourceType).put("messageHash", parsed.messageHash)
                .put("detectedAtMillis", parsed.detectedAtMillis)
            val ingested = request("ingest.php", event)
            val status = ingested.optString("status", "received")
            if (status == "duplicate") return PaymentLogEntry(parsed.txIdNormalized, parsed.method.id, parsed.amount, parsed.senderNumber, parsed.sourceType, "DUPLICATE", "এই TrxID আগে পাওয়া হয়েছে।", System.currentTimeMillis())
            val matched = request("match.php", JSONObject().put("method", parsed.method.id).put("txId", parsed.txIdNormalized))
            val result = matched.optString("status", "unmatched")
            val badge = if (result == "credited") { approved.incrementAndGet(); "APPROVED" } else "WAITING"
            PaymentLogEntry(parsed.txIdNormalized, parsed.method.id, parsed.amount, parsed.senderNumber, parsed.sourceType, badge,
                if (badge == "APPROVED") "MySQL Wallet-এ টাকা যোগ হয়েছে।" else "মিল পাওয়া যায়নি; Admin review প্রয়োজন।", System.currentTimeMillis())
        } catch (e: Exception) {
            PaymentLogEntry(parsed.txIdNormalized, parsed.method.id, parsed.amount, parsed.senderNumber, parsed.sourceType, "ERROR", e.message ?: "API error", System.currentTimeMillis())
        }
    }

    fun reconcileAllPayments(): ReconciliationResult {
        val pending = syncDashboardMetrics()
        return ReconciliationResult(0, pending, 0, 0, 0, 0, "MySQL সার্ভার থেকে Dashboard আপডেট হয়েছে।")
    }
    fun reconcilePendingDeposits(): Int = reconcileAllPayments().approvedCount

    fun diagnoseTrxIdReadOnly(rawInput: String): String {
        val parsed = PaymentMessageParser.parseSampleForTest(rawInput)
        return if (parsed == null) "SMS থেকে Method, Amount ও TrxID শনাক্ত করা যায়নি।" else
            "Method: ${parsed.method.displayName}\nAmount: ৳${parsed.amount}\nTrxID: ${parsed.txIdNormalized}\nSender: ${parsed.senderNumber}\nএটি শুধু Parser Test; Wallet পরিবর্তন করেনি।"
    }
}
