OBITO MART AUTO PAYMENT SYSTEM — ANDROID SOURCE ONLY
Version: 1.1.0

এই ZIP-এ শুধু Android Studio Project রাখা হয়েছে। Website/PHP ফাইল এতে নেই।

প্রধান বৈশিষ্ট্য:
- Activation Key ও device registration
- bKash, Nagad ও Rocket incoming payment SMS/notification parsing
- MySQL-backed HTTPS API: https://obitomart.byethost8.com/api/autopay/
- Payment history, diagnostics, settings এবং dashboard metrics
- Professional dark navy + electric-blue UI polish

UI আপডেটে layout-এর বিদ্যমান View ID ও Activity logic অক্ষত রাখার চেষ্টা করা হয়েছে।
অ্যাপের payment/SMS behavior বা backend protocol ইচ্ছাকৃতভাবে বদলানো হয়নি।

Build:
1. Android Studio-তে এই project folder open করুন।
2. Gradle sync শেষ করুন।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।

নোট:
- এই ZIP source project; prebuilt APK নয়।
- বাস্তব bKash/Nagad/Rocket SMS, device permissions, backend matching এবং duplicate transaction test এখানে চালানো হয়নি।
- live customer payment চালুর আগে নিজের নিয়ন্ত্রিত ছোট test transaction দিয়ে পরীক্ষা করুন।
- SMS/Notification access শুধুমাত্র অনুমোদিত admin device-এ, ব্যবহারকারীর স্পষ্ট সম্মতিতে দিন।


VERSION 1.1.1 DIAGNOSTIC UPDATE
- Android API client now detects non-JSON/HTML responses safely and displays HTTP status, Content-Type and a short sanitized response preview.
- Redirects are not silently followed, so hosting redirect/WAF errors can be identified.
- API_BASE remains https://obitomart.byethost8.com/api/autopay/.
- No Firebase or additional third-party account/service is required for this PHP/MySQL build.


BYETHOST API COOKIE HANDLING (v1.2.0)
- Activation first opens the API endpoint in Android WebView so ByetHost's JavaScript __test cookie challenge can run.
- The resulting cookie is stored locally and attached to native PHP API requests.
- This is a compatibility workaround based on the ByetHost testcookie-nginx-module flow; it still requires a real APK build and live POST/activation test.


BYETHOST COOKIE BOOTSTRAP CORRECTION (v1.2.1)
- Previous test build opened activate.php with GET. That endpoint returns JSON "POST required" and may not trigger the browser challenge.
- This build opens the site's HTTPS homepage in WebView, waits for the __test cookie, then sends that cookie with the native API POST.
- This is still an unverified compatibility attempt. It does not guarantee that ByetHost will accept native app requests.
- Do not use for real customer payments until a real release build passes activation, heartbeat, SMS ingest, matching, duplicate TrxID, and wallet-credit tests.
