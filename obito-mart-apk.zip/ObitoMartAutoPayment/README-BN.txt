OBITO MART AUTO PAYMENT — BYETHOST WEBVIEW API SESSION v1.2.1

এই Source-এ Native HttpURLConnection থেকে API POST পাঠানোর বদলে একই-origin Android WebView session ব্যবহার করা হয়েছে। WebView-তে ByetHost homepage/browser verification শেষ হওয়ার পর সেই একই session থেকে fetch() দিয়ে PHP API POST হয়; এতে browser-managed cookies নিজে কপি করার প্রয়োজন হয় না।

API Base: https://obitomart.byethost8.com/api/autopay/

GitHub Actions workflow: .github/workflows/build-apk.yml
Artifact: OBITO-MART-AUTO-PAYMENT-v1.2.1-APK

গুরুত্বপূর্ণ: এটি source-level workaround, ByetHost-এর live OpenResty challenge pass করে কি না এখনও নিশ্চিত নয়। Build, real device activation, SMS/notification listener, heartbeat, bKash/Nagad/Rocket ingestion, TrxID matching ও wallet credit আলাদাভাবে live test করতে হবে।

Android app-এ MySQL password নেই। Database connection শুধুমাত্র PHP server-side config/database.php দিয়ে হয়।
