package com.obitomart.autopayment.data

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/** Executes the ByetHost browser challenge in a same-origin WebView session,
 * first opens the exact API endpoint with GET so any path-specific challenge runs,
 * then sends POST from that same browser session. Chromium manages cookies.
 */
internal object ByetHostWebViewApiClient {
    private const val ORIGIN = "https://obitomart.byethost8.com"

    private data class Reply(val status: Int, val contentType: String, val body: String)

    fun post(context: Context, endpoint: String, body: JSONObject, timeoutSeconds: Long = 50): JSONObject {
        require(endpoint.startsWith("$ORIGIN/")) { "Blocked API origin" }
        val latch = CountDownLatch(1)
        val reply = AtomicReference<Reply?>(null)
        val failure = AtomicReference<String?>(null)
        val main = Handler(Looper.getMainLooper())
        val webRef = AtomicReference<WebView?>(null)

        val bridge = object {
            @JavascriptInterface
            fun onResponse(status: Int, contentType: String?, raw: String?) {
                reply.compareAndSet(null, Reply(status, contentType ?: "unknown", raw ?: ""))
                latch.countDown()
            }
            @JavascriptInterface
            fun onFailure(message: String?) {
                failure.compareAndSet(null, message ?: "Browser API request failed")
                latch.countDown()
            }
        }

        main.post {
            try {
                val web = WebView(context)
                webRef.set(web)
                web.settings.javaScriptEnabled = true
                web.settings.domStorageEnabled = true
                web.settings.databaseEnabled = true
                web.settings.javaScriptCanOpenWindowsAutomatically = false
                web.settings.setSupportMultipleWindows(false)
                web.addJavascriptInterface(bridge, "ObitoNative")
                web.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                        return request.url.host != "obitomart.byethost8.com"
                    }

                    override fun onPageFinished(view: WebView, url: String) {
                        if (!url.startsWith(ORIGIN)) {
                            failure.compareAndSet(null, "Unexpected redirect outside OBITO MART host")
                            latch.countDown()
                            return
                        }
                        val endpointJs = JSONObject.quote(endpoint)
                        val bodyJs = JSONObject.quote(body.toString())
                        val script = """
                            (function(){
                              if(window.__obitoPollStarted) return;
                              window.__obitoPollStarted=true;
                              var endpoint=$endpointJs;
                              var payload=$bodyJs;
                              var attempts=0;
                              function run(){
                                if(window.__obitoApiSent) return;
                                attempts++;
                                var txt=((document.body && document.body.innerText)||'').toLowerCase();
                                var challenge = txt.indexOf('this site requires javascript')>=0 ||
                                  txt.indexOf('please enable javascript')>=0 ||
                                  txt.indexOf('checking your browser')>=0 ||
                                  txt.indexOf('javascript verification')>=0;
                                if(challenge || document.readyState!=='complete'){
                                  if(attempts<75){ setTimeout(run,600); return; }
                                  window.ObitoNative.onFailure('ByetHost browser verification did not finish.');
                                  return;
                                }
                                // Give challenge scripts/cookie writes one extra turn before API call.
                                window.__obitoApiSent=true;
                                setTimeout(function(){
                                  fetch(endpoint, {method:'POST', credentials:'include', cache:'no-store',
                                    headers:{'Content-Type':'application/json; charset=utf-8','Accept':'application/json'},
                                    body:payload
                                  }).then(async function(r){
                                    var t=await r.text();
                                    window.ObitoNative.onResponse(r.status, r.headers.get('content-type')||'unknown', t);
                                  }).catch(function(e){ window.ObitoNative.onFailure(String(e)); });
                                },900);
                              }
                              run();
                            })();
                        """.trimIndent()
                        view.evaluateJavascript(script, null)
                    }
                }
                web.loadUrl(endpoint)
            } catch (t: Throwable) {
                failure.set(t.message ?: t.javaClass.simpleName)
                latch.countDown()
            }
        }

        val completed = latch.await(timeoutSeconds, TimeUnit.SECONDS)
        main.post {
            try { webRef.get()?.stopLoading(); webRef.get()?.removeJavascriptInterface("ObitoNative"); webRef.get()?.destroy() } catch (_: Throwable) { }
        }
        if (!completed) throw IllegalStateException("ByetHost API browser session timed out")
        failure.get()?.let { throw IllegalStateException(it) }
        val r = reply.get() ?: throw IllegalStateException("No API response received")
        val json = try { JSONObject(r.body) } catch (_: Exception) {
            val preview = r.body.replace(Regex("(?is)<script.*?</script>"), " ")
                .replace(Regex("(?is)<style.*?</style>"), " ")
                .replace(Regex("<[^>]*>"), " ").replace(Regex("\\s+"), " ").trim().take(240)
            throw IllegalStateException("API JSON নয় (HTTP ${r.status}, ${r.contentType}): ${preview.ifBlank { "খালি response" }}")
        }
        if (r.status !in 200..299 || !json.optBoolean("ok", false)) {
            throw IllegalStateException("${json.optString("error", "HTTP ${r.status}")} (HTTP ${r.status})")
        }
        return json
    }
}
