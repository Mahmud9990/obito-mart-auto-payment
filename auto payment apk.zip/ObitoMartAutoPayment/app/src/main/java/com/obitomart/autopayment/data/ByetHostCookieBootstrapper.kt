package com.obitomart.autopayment.data

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/**
 * Lets Android WebView execute ByetHost's own JavaScript browser check once.
 * The resulting __test cookie is then sent by the native API client.
 */
internal object ByetHostCookieBootstrapper {
    fun obtain(context: Context, url: String, timeoutSeconds: Long = 25): String {
        val cookies = CookieManager.getInstance()
        cookies.setAcceptCookie(true)

        val existing = cookies.getCookie(url).orEmpty()
        if (existing.split(";").any { it.trim().startsWith("__test=") }) return existing

        val latch = CountDownLatch(1)
        val result = AtomicReference("")
        val webViewRef = AtomicReference<WebView?>(null)
        val main = Handler(Looper.getMainLooper())

        main.post {
            try {
                val webView = WebView(context)
                webViewRef.set(webView)
                webView.settings.javaScriptEnabled = true
                webView.settings.domStorageEnabled = true
                webView.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, finishedUrl: String) {
                        CookieManager.getInstance().flush()
                        val current = CookieManager.getInstance().getCookie(url).orEmpty()
                        if (current.split(";").any { it.trim().startsWith("__test=") }) {
                            result.set(current)
                            latch.countDown()
                        }
                    }
                }
                webView.loadUrl(url)
            } catch (_: Throwable) {
                latch.countDown()
            }
        }

        val completed = latch.await(timeoutSeconds, TimeUnit.SECONDS)
        val cookie = result.get()
        main.post {
            try {
                webViewRef.get()?.stopLoading()
                webViewRef.get()?.destroy()
            } catch (_: Throwable) { }
        }
        if (!completed || cookie.isBlank()) {
            throw IllegalStateException(
                "ByetHost security cookie পাওয়া যায়নি। Browser verification শেষ হয়নি; ইন্টারনেট সংযোগ ও Hosting challenge পরীক্ষা করুন।"
            )
        }
        return cookie
    }
}
