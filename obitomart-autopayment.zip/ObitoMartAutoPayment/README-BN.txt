OBITO MART AUTO PAYMENT — INFINITYFREE WEBVIEW API SESSION v1.0

এই Source-এ Native HttpURLConnection থেকে API POST পাঠানোর বদলে একই-origin Android WebView session ব্যবহার করা হয়েছে। WebView-তে InfinityFree homepage/browser verification শেষ হওয়ার পর সেই একই session থেকে fetch() দিয়ে PHP API POST হয়; এতে browser-managed cookies নিজে কপি করার প্রয়োজন হয় না।

API Base: https://obitomart.gamer.gd/api/autopay/

GitHub Actions workflow: .github/workflows/build-apk.yml
Artifact: OBITO-MART-AUTO-PAYMENT-v1.2.1-APK

গুরুত্বপূর্ণ: এটি source-level workaround, InfinityFree-এর live OpenResty challenge pass করে কি না এখনও নিশ্চিত নয়। Build, real device activation, SMS/notification listener, heartbeat, bKash/Nagad/Rocket ingestion, TrxID matching ও wallet credit আলাদাভাবে live test করতে হবে।

Android app-এ MySQL password নেই। Database connection শুধুমাত্র PHP server-side config/database.php দিয়ে হয়।


API Base: https://obitomart.gamer.gd/api/autopay/
Android app-এ MySQL password রাখা হয়নি; database config কেবল PHP hosting-এ থাকবে।
নোট: অ্যাপ ওপেন হওয়া বা Activation screen দেখা মানেই API/AutoPay সফল নয়। Live activation, heartbeat, SMS ingestion, matching এবং wallet credit আলাদাভাবে পরীক্ষা করতে হবে।
