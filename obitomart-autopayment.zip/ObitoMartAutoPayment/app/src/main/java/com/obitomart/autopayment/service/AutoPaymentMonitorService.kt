package com.obitomart.autopayment.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.obitomart.autopayment.ObitoAutoPayApp
import com.obitomart.autopayment.ObitoBroadcasts
import com.obitomart.autopayment.R
import com.obitomart.autopayment.data.AutoPaymentPrefs
import com.obitomart.autopayment.data.MysqlAutoPaymentRepository
import com.obitomart.autopayment.ui.MainActivity
import android.util.Log
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Foreground Monitor Service for Android 7.0–14+.
 * Sends periodic heartbeats to `autoPaymentDevices/{deviceId}` and bidirectionally reconciles
 * pending `depositRequests` and unmatched `incomingPayments` every 12 seconds, plus rapid
 * follow-up checks (+5s, +15s, +30s, +55s) whenever an SMS arrives before user submission.
 */
class AutoPaymentMonitorService : Service() {

    private var scheduler: ScheduledExecutorService? = null
    private val loopRunning = AtomicBoolean(false)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prefs = AutoPaymentPrefs(applicationContext)

        // Always satisfy the OS foreground service contract immediately to prevent
        // ForegroundServiceDidNotStartInTimeException on Android 8.0-14+
        val notification = buildForegroundNotification()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                try {
                    startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                    )
                } catch (e: Throwable) {
                    // Fallback to standard startForeground if dataSync type is restricted by OEM
                    startForeground(NOTIFICATION_ID, notification)
                }
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Throwable) {
            Log.w("AutoPayService", "startForeground failed: ${e.message}")
        }

        if (intent?.action == ACTION_STOP_MONITORING || !prefs.hasAcceptedConsent || !prefs.isDeviceActivated) {
            prefs.isMonitoringEnabled = false
            loopRunning.set(false)
            scheduler?.shutdownNow()
            scheduler = null
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
            Executors.newSingleThreadExecutor().execute {
                try {
                    MysqlAutoPaymentRepository(applicationContext).updateHeartbeat(false)
                    ObitoBroadcasts.notifyUiLogUpdated(applicationContext)
                } catch (_: Throwable) {}
                stopSelf()
            }
            return START_NOT_STICKY
        }

        ensureSyncLoopStarted()

        if (intent?.action == ACTION_RAPID_RECONCILE) {
            scheduleRapidFollowUpChecks()
        }

        return START_STICKY
    }

    private fun ensureSyncLoopStarted() {
        val current = scheduler
        if (current != null && !current.isShutdown && loopRunning.get()) {
            return
        }
        current?.shutdownNow()
        val exec = Executors.newSingleThreadScheduledExecutor()
        scheduler = exec
        loopRunning.set(true)

        exec.scheduleWithFixedDelay(
            {
                runSingleSyncCycle()
            },
            0L,
            12L,
            TimeUnit.SECONDS
        )
    }

    private fun scheduleRapidFollowUpChecks() {
        val exec = scheduler ?: return
        if (exec.isShutdown) return
        val delaysSec = longArrayOf(5L, 15L, 30L, 55L)
        for (delay in delaysSec) {
            try {
                exec.schedule({ runSingleSyncCycle() }, delay, TimeUnit.SECONDS)
            } catch (_: Exception) {
                // Ignore if executor is shutting down
            }
        }
    }

    private fun runSingleSyncCycle() {
        try {
            val prefs = AutoPaymentPrefs(applicationContext)
            if (!prefs.isDeviceActivated) {
                stopSelf()
                return
            }
            val repo = MysqlAutoPaymentRepository(applicationContext)
            val sessionStatus = repo.checkDeviceSessionStatus()
            if (sessionStatus == "REVOKED") {
                prefs.clearActivationSession()
                ObitoBroadcasts.notifyUiLogUpdated(applicationContext)
                stopSelf()
                return
            }
            repo.updateHeartbeat(true)
            val result = repo.reconcileAllPayments()
            for (approvedEntry in result.newlyApprovedEntries) {
                ObitoBroadcasts.postApprovedPaymentNotification(applicationContext, approvedEntry)
            }
            if (result.logsChanged || result.approvedCount > 0) {
                ObitoBroadcasts.notifyUiLogUpdated(applicationContext)
            }
        } catch (e: Exception) {
            AutoPaymentPrefs(applicationContext).appendDiagnostic(
                "WARN",
                "SYNC_CYCLE_ERR",
                "",
                e.localizedMessage ?: "Background sync error"
            )
        }
    }

    @Suppress("DEPRECATION")
    private fun buildForegroundNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = PendingIntent.getActivity(
            this,
            1001,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, AutoPaymentMonitorService::class.java).apply {
            action = ACTION_STOP_MONITORING
        }
        val stopPending = PendingIntent.getService(
            this,
            1002,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, ObitoAutoPayApp.CHANNEL_MONITOR)
        } else {
            Notification.Builder(this)
        }

        val stopAction = Notification.Action.Builder(0, "বন্ধ করুন", stopPending).build()

        return builder
            .setSmallIcon(R.drawable.ic_stat_autopay)
            .setContentTitle("OBITO MART অটো-পেমেন্ট সক্রিয়")
            .setContentText("bKash, Nagad ও Rocket ইনকামিং পেমেন্ট যাচাই চালু আছে")
            .setOngoing(true)
            .setContentIntent(openPending)
            .addAction(stopAction)
            .build()
    }

    override fun onDestroy() {
        loopRunning.set(false)
        scheduler?.shutdownNow()
        scheduler = null
        super.onDestroy()
    }

    companion object {
        private const val NOTIFICATION_ID = 4101
        const val ACTION_STOP_MONITORING = "com.obitomart.autopayment.ACTION_STOP_MONITORING"
        const val ACTION_RAPID_RECONCILE = "com.obitomart.autopayment.ACTION_RAPID_RECONCILE"

        fun start(context: Context) {
            try {
                val intent = Intent(context, AutoPaymentMonitorService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (_: Exception) {
                // Ignore background start restriction if app is restricted by OEM
            }
        }

        fun triggerRapidReconcile(context: Context) {
            try {
                val intent = Intent(context, AutoPaymentMonitorService::class.java).apply {
                    action = ACTION_RAPID_RECONCILE
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (_: Exception) {
                // Fallback in-process delayed retries if foreground start is blocked
                val fallbackExec = Executors.newSingleThreadScheduledExecutor()
                for (delay in longArrayOf(6L, 18L, 40L)) {
                    fallbackExec.schedule(
                        {
                            try {
                                val res = MysqlAutoPaymentRepository(context.applicationContext).reconcileAllPayments()
                                for (entry in res.newlyApprovedEntries) {
                                    ObitoBroadcasts.postApprovedPaymentNotification(context.applicationContext, entry)
                                }
                                if (res.logsChanged || res.approvedCount > 0) {
                                    ObitoBroadcasts.notifyUiLogUpdated(context.applicationContext)
                                }
                            } catch (_: Exception) {}
                        },
                        delay,
                        TimeUnit.SECONDS
                    )
                }
                fallbackExec.schedule({ fallbackExec.shutdown() }, 45L, TimeUnit.SECONDS)
            }
        }

        fun stop(context: Context) {
            try {
                val intent = Intent(context, AutoPaymentMonitorService::class.java).apply {
                    action = ACTION_STOP_MONITORING
                }
                context.startService(intent)
            } catch (_: Exception) {
                context.stopService(Intent(context, AutoPaymentMonitorService::class.java))
            }
        }
    }
}
