package com.obitomart.autopayment.ui

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.obitomart.autopayment.ObitoBroadcasts
import com.obitomart.autopayment.R
import com.obitomart.autopayment.data.AutoPaymentPrefs
import com.obitomart.autopayment.data.MysqlAutoPaymentRepository
import com.obitomart.autopayment.model.PaymentLogEntry
import com.obitomart.autopayment.parser.PaymentMessageParser
import com.obitomart.autopayment.service.AutoPaymentMonitorService
import com.obitomart.autopayment.service.PaymentNotificationListenerService
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {

    companion object {
        private const val REQ_CODE_PERMISSIONS = 501
    }

    private lateinit var prefs: AutoPaymentPrefs
    private lateinit var repo: MysqlAutoPaymentRepository
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var suppressSwitchCallback = false
    private var currentFilterMode = "ALL"

    // Top Level Containers
    private lateinit var layoutActivationScreen: ScrollView
    private lateinit var layoutMainDashboard: LinearLayout

    // Activation Views
    private lateinit var etActivationKey: EditText
    private lateinit var etDeviceName: EditText
    private lateinit var btnActivateDevice: Button
    private lateinit var tvActivationStatus: TextView

    // Header Views
    private lateinit var tvHeaderTitle: TextView
    private lateinit var tvHeaderDeviceStatus: TextView
    private lateinit var tvHeaderPill: TextView

    // Bottom Navigation Tab Buttons
    private lateinit var btnTabDashboard: Button
    private lateinit var btnTabReader: Button
    private lateinit var btnTabHistory: Button
    private lateinit var btnTabDiagnostics: Button
    private lateinit var btnTabSettings: Button

    // Tab Content Views
    private lateinit var viewTabDashboard: ScrollView
    private lateinit var viewTabReader: ScrollView
    private lateinit var viewTabHistory: ScrollView
    private lateinit var viewTabDiagnostics: ScrollView
    private lateinit var viewTabSettings: ScrollView

    // Dashboard Tab Views
    private lateinit var switchDashboardMonitoring: Switch
    private lateinit var tvDashboardServiceSubtitle: TextView
    private lateinit var tvStatDetectedCount: TextView
    private lateinit var tvStatApprovedCount: TextView
    private lateinit var tvTodayAutoMoney: TextView
    private lateinit var tvStatPendingCount: TextView
    private lateinit var tvStatSuccessRate: TextView
    private lateinit var btnQuickReconcile: Button
    private lateinit var tvLastSyncSummary: TextView
    private lateinit var containerRecentActivity: LinearLayout
    private lateinit var tvEmptyRecentActivity: TextView

    // SMS Reader Tab Views
    private lateinit var tvReaderSmsStatus: TextView
    private lateinit var btnGrantReaderSms: Button
    private lateinit var tvReaderNotifStatus: TextView
    private lateinit var btnGrantReaderNotif: Button
    private lateinit var btnRestrictedSettingsHelp: TextView
    private lateinit var containerLiveSmsList: LinearLayout
    private lateinit var tvEmptyLiveSms: TextView

    // Payment History Tab Views
    private lateinit var btnFilterAll: Button
    private lateinit var btnFilterApproved: Button
    private lateinit var btnFilterWaiting: Button
    private lateinit var btnFilterErrors: Button
    private lateinit var containerHistoryList: LinearLayout
    private lateinit var tvEmptyHistory: TextView

    // Diagnostics Tab Views
    private lateinit var etSampleSms: EditText
    private lateinit var btnTestParseOnly: Button
    private lateinit var btnDiagnoseServerMatch: Button
    private lateinit var tvTestParseResult: TextView
    private lateinit var btnCopyDiagnostics: Button
    private lateinit var btnClearDiagnostics: Button
    private lateinit var tvDiagnosticLogs: TextView

    // Settings Tab Views
    private lateinit var tvSettingDeviceId: TextView
    private lateinit var tvSettingDeviceName: TextView
    private lateinit var tvSettingKeyUsed: TextView
    private lateinit var tvSettingActivatedAt: TextView
    private lateinit var btnReviewConsent: Button
    private lateinit var btnDeactivateDevice: Button

    private val timeFormat = SimpleDateFormat("dd MMM, hh:mm:ss a", Locale.getDefault())
    private val shortTimeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    private val logUpdateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshMetricsAndRecentFeeds()
            refreshHistoryList()
            refreshPermissionViews()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            prefs = AutoPaymentPrefs(this)
            repo = MysqlAutoPaymentRepository(this)

            setContentView(R.layout.activity_main)

            bindViews()
            setupActivationControls()
            setupNavigationTabs()
            setupDashboardControls()
            setupReaderControls()
            setupHistoryFilters()
            setupDiagnosticsControls()
            setupSettingsControls()

            refreshScreenMode()
        } catch (e: Throwable) {
            android.util.Log.e("MainActivity", "FATAL STARTUP EXCEPTION in onCreate: ${e.message}", e)
            val sw = java.io.StringWriter()
            e.printStackTrace(java.io.PrintWriter(sw))
            val trace = sw.toString()
            try {
                prefs.lastFatalCrashMsg = e.localizedMessage ?: e.javaClass.simpleName
                prefs.lastFatalCrashTrace = trace
                prefs.lastFatalCrashTime = System.currentTimeMillis()
            } catch (_: Throwable) {}
            renderStartupRescueView(e, trace)
        }
    }

    private fun renderStartupRescueView(error: Throwable, trace: String) {
        val root = ScrollView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(0xFF0F172A.toInt()) // Deep slate background
            isFillViewport = true
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 48)
        }

        val tvTitle = TextView(this).apply {
            text = "OBITO MART AUTO PAYMENT"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

        val tvSub = TextView(this).apply {
            text = "Startup Exception Diagnostic Screen"
            setTextColor(0xFFEF4444.toInt())
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 8, 0, 16)
        }

        val tvNotice = TextView(this).apply {
            text = "অ্যাপ চালুর সময় ত্রুটি শনাক্ত হয়েছে (Exception: ${error.javaClass.simpleName}):\n${error.localizedMessage ?: "Unknown initialization error"}"
            setTextColor(0xFFF1F5F9.toInt())
            textSize = 13f
            setPadding(0, 0, 0, 16)
        }

        val tvTrace = TextView(this).apply {
            text = trace
            setTextColor(0xFF94A3B8.toInt())
            textSize = 11f
            typeface = android.graphics.Typeface.MONOSPACE
            setBackgroundColor(0xFF1E293B.toInt())
            setPadding(20, 20, 20, 20)
        }

        val btnCopy = Button(this).apply {
            text = "Copy Error Details"
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF7C3AED.toInt())
            setPadding(0, 16, 0, 16)
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                cm?.setPrimaryClip(ClipData.newPlainText("ObitoMartCrashTrace", trace))
                Toast.makeText(this@MainActivity, "ত্রুটির সম্পূর্ণ বিবরণ কপি হয়েছে", Toast.LENGTH_SHORT).show()
            }
        }

        val btnRestart = Button(this).apply {
            text = "পুনরায় চেষ্টা করুন (Retry)"
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF334155.toInt())
            setPadding(0, 16, 0, 16)
            setOnClickListener {
                recreate()
            }
        }

        val btnParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = 24
        }

        container.addView(tvTitle)
        container.addView(tvSub)
        container.addView(tvNotice)
        container.addView(btnCopy, btnParams)
        container.addView(btnRestart, LinearLayout.LayoutParams(btnParams).apply { topMargin = 12 })
        container.addView(tvTrace, LinearLayout.LayoutParams(btnParams).apply { topMargin = 24 })

        root.addView(container)
        setContentView(root)
    }

    private fun bindViews() {
        layoutActivationScreen = findViewById(R.id.layoutActivationScreen)
        layoutMainDashboard = findViewById(R.id.layoutMainDashboard)

        // Activation
        etActivationKey = findViewById(R.id.etActivationKey)
        etDeviceName = findViewById(R.id.etDeviceName)
        btnActivateDevice = findViewById(R.id.btnActivateDevice)
        tvActivationStatus = findViewById(R.id.tvActivationStatus)

        // Header
        tvHeaderTitle = findViewById(R.id.tvHeaderTitle)
        tvHeaderDeviceStatus = findViewById(R.id.tvHeaderDeviceStatus)
        tvHeaderPill = findViewById(R.id.tvHeaderPill)

        // Navigation
        btnTabDashboard = findViewById(R.id.btnTabDashboard)
        btnTabReader = findViewById(R.id.btnTabReader)
        btnTabHistory = findViewById(R.id.btnTabHistory)
        btnTabDiagnostics = findViewById(R.id.btnTabDiagnostics)
        btnTabSettings = findViewById(R.id.btnTabSettings)

        // Tabs
        viewTabDashboard = findViewById(R.id.viewTabDashboard)
        viewTabReader = findViewById(R.id.viewTabReader)
        viewTabHistory = findViewById(R.id.viewTabHistory)
        viewTabDiagnostics = findViewById(R.id.viewTabDiagnostics)
        viewTabSettings = findViewById(R.id.viewTabSettings)

        // Dashboard
        switchDashboardMonitoring = findViewById(R.id.switchDashboardMonitoring)
        tvDashboardServiceSubtitle = findViewById(R.id.tvDashboardServiceSubtitle)
        tvStatDetectedCount = findViewById(R.id.tvStatDetectedCount)
        tvStatApprovedCount = findViewById(R.id.tvStatApprovedCount)
        tvTodayAutoMoney = findViewById(R.id.tvTodayAutoMoney)
        tvStatPendingCount = findViewById(R.id.tvStatPendingCount)
        tvStatSuccessRate = findViewById(R.id.tvStatSuccessRate)
        btnQuickReconcile = findViewById(R.id.btnQuickReconcile)
        tvLastSyncSummary = findViewById(R.id.tvLastSyncSummary)
        containerRecentActivity = findViewById(R.id.containerRecentActivity)
        tvEmptyRecentActivity = findViewById(R.id.tvEmptyRecentActivity)

        // Reader
        tvReaderSmsStatus = findViewById(R.id.tvReaderSmsStatus)
        btnGrantReaderSms = findViewById(R.id.btnGrantReaderSms)
        tvReaderNotifStatus = findViewById(R.id.tvReaderNotifStatus)
        btnGrantReaderNotif = findViewById(R.id.btnGrantReaderNotif)
        btnRestrictedSettingsHelp = findViewById(R.id.btnRestrictedSettingsHelp)
        containerLiveSmsList = findViewById(R.id.containerLiveSmsList)
        tvEmptyLiveSms = findViewById(R.id.tvEmptyLiveSms)

        // History
        btnFilterAll = findViewById(R.id.btnFilterAll)
        btnFilterApproved = findViewById(R.id.btnFilterApproved)
        btnFilterWaiting = findViewById(R.id.btnFilterWaiting)
        btnFilterErrors = findViewById(R.id.btnFilterErrors)
        containerHistoryList = findViewById(R.id.containerHistoryList)
        tvEmptyHistory = findViewById(R.id.tvEmptyHistory)

        // Diagnostics
        etSampleSms = findViewById(R.id.etSampleSms)
        btnTestParseOnly = findViewById(R.id.btnTestParseOnly)
        btnDiagnoseServerMatch = findViewById(R.id.btnDiagnoseServerMatch)
        tvTestParseResult = findViewById(R.id.tvTestParseResult)
        btnCopyDiagnostics = findViewById(R.id.btnCopyDiagnostics)
        btnClearDiagnostics = findViewById(R.id.btnClearDiagnostics)
        tvDiagnosticLogs = findViewById(R.id.tvDiagnosticLogs)

        // Settings
        tvSettingDeviceId = findViewById(R.id.tvSettingDeviceId)
        tvSettingDeviceName = findViewById(R.id.tvSettingDeviceName)
        tvSettingKeyUsed = findViewById(R.id.tvSettingKeyUsed)
        tvSettingActivatedAt = findViewById(R.id.tvSettingActivatedAt)
        btnReviewConsent = findViewById(R.id.btnReviewConsent)
        btnDeactivateDevice = findViewById(R.id.btnDeactivateDevice)
    }

    @Suppress("UnspecifiedRegisterReceiverFlag")
    override fun onStart() {
        super.onStart()
        try {
            val filter = IntentFilter(ObitoBroadcasts.ACTION_LOG_UPDATED)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(logUpdateReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(logUpdateReceiver, filter)
            }
        } catch (e: Throwable) {
            android.util.Log.w("MainActivity", "Failed to register log receiver: ${e.message}")
        }
    }

    private val foregroundAutoSyncRunnable = object : Runnable {
        override fun run() {
            try {
                if (prefs.isDeviceActivated) {
                    checkDeviceSessionAndSync()
                }
            } catch (e: Throwable) {
                android.util.Log.w("MainActivity", "foregroundAutoSyncRunnable failed: ${e.message}")
            }
            mainHandler.postDelayed(this, 10_000L)
        }
    }

    override fun onResume() {
        super.onResume()
        try {
            refreshScreenMode()
            if (prefs.isDeviceActivated) {
                if (prefs.hasAcceptedConsent && prefs.isMonitoringEnabled) {
                    try {
                        AutoPaymentMonitorService.start(this)
                    } catch (e: Throwable) {
                        android.util.Log.w("MainActivity", "Failed to start AutoPaymentMonitorService in onResume: ${e.message}")
                    }
                }
                checkDeviceSessionAndSync()
            }
            mainHandler.removeCallbacks(foregroundAutoSyncRunnable)
            mainHandler.postDelayed(foregroundAutoSyncRunnable, 10_000L)
        } catch (e: Throwable) {
            android.util.Log.e("MainActivity", "FATAL in onResume: ${e.message}", e)
            val sw = java.io.StringWriter()
            e.printStackTrace(java.io.PrintWriter(sw))
            val trace = sw.toString()
            try {
                prefs.lastFatalCrashMsg = e.localizedMessage ?: e.javaClass.simpleName
                prefs.lastFatalCrashTrace = trace
                prefs.lastFatalCrashTime = System.currentTimeMillis()
            } catch (_: Throwable) {}
            renderStartupRescueView(e, trace)
        }
    }

    override fun onPause() {
        mainHandler.removeCallbacks(foregroundAutoSyncRunnable)
        super.onPause()
    }

    override fun onStop() {
        super.onStop()
        try {
            unregisterReceiver(logUpdateReceiver)
        } catch (_: Throwable) {}
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        ioExecutor.shutdownNow()
        super.onDestroy()
    }

    private fun checkDeviceSessionAndSync() {
        if (!prefs.isDeviceActivated) return
        ioExecutor.execute {
            try {
                val status = repo.checkDeviceSessionStatus()
                if (status == "REVOKED") {
                    mainHandler.post {
                        Toast.makeText(this, "Admin Panel থেকে এই ডিভাইস Revoke করা হয়েছে!", Toast.LENGTH_LONG).show()
                        AutoPaymentMonitorService.stop(this)
                        refreshScreenMode()
                    }
                    return@execute
                }

                repo.updateHeartbeat(prefs.isMonitoringEnabled)
                val result = repo.reconcileAllPayments()
                val pendingNow = repo.syncDashboardMetrics()

                for (approvedEntry in result.newlyApprovedEntries) {
                    ObitoBroadcasts.postApprovedPaymentNotification(applicationContext, approvedEntry)
                }

                mainHandler.post {
                    tvStatPendingCount.text = pendingNow.toString()
                    tvLastSyncSummary.text = result.summaryMessageBn
                    refreshMetricsAndRecentFeeds()
                    refreshHistoryList()
                }
            } catch (e: Throwable) {
                android.util.Log.w("MainActivity", "Background sync error: ${e.message}")
            }
        }
    }

    private fun refreshScreenMode() {
        try {
            if (!prefs.isDeviceActivated) {
                layoutActivationScreen.visibility = View.VISIBLE
                layoutMainDashboard.visibility = View.GONE
                etDeviceName.setText(prefs.deviceName)
            } else {
                layoutActivationScreen.visibility = View.GONE
                layoutMainDashboard.visibility = View.VISIBLE
                tvHeaderDeviceStatus.text = "${prefs.deviceName} • Active"
                refreshMetricsAndRecentFeeds()
                refreshPermissionViews()
                refreshHistoryList()
                refreshSettingsView()
            }
        } catch (e: Throwable) {
            android.util.Log.e("MainActivity", "Error in refreshScreenMode: ${e.message}", e)
        }
    }

    private fun setupActivationControls() {
        btnActivateDevice.setOnClickListener {
            val rawKey = etActivationKey.text?.toString()?.trim().orEmpty()
            val deviceName = etDeviceName.text?.toString()?.trim().orEmpty()

            if (rawKey.isBlank()) {
                tvActivationStatus.visibility = View.VISIBLE
                tvActivationStatus.text = "অনুগ্রহ করে Admin Panel থেকে পাওয়া Activation Key দিন।"
                return@setOnClickListener
            }

            btnActivateDevice.isEnabled = false
            btnActivateDevice.text = "যাচাই করা হচ্ছে..."
            tvActivationStatus.visibility = View.GONE

            ioExecutor.execute {
                val (ok, msg) = repo.activateWithKey(rawKey, deviceName)
                mainHandler.post {
                    btnActivateDevice.isEnabled = true
                    btnActivateDevice.text = "Activate & Connect Device"

                    if (ok) {
                        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                        if (!prefs.hasAcceptedConsent) {
                            showExplicitConsentDialog {
                                requestSmsAndPostNotificationPermissions()
                            }
                        } else {
                            requestSmsAndPostNotificationPermissions()
                        }
                        AutoPaymentMonitorService.start(this)
                        refreshScreenMode()
                        checkDeviceSessionAndSync()
                    } else {
                        tvActivationStatus.visibility = View.VISIBLE
                        tvActivationStatus.text = msg
                    }
                }
            }
        }
    }

    private fun setupNavigationTabs() {
        val tabs = listOf(
            btnTabDashboard to viewTabDashboard,
            btnTabReader to viewTabReader,
            btnTabHistory to viewTabHistory,
            btnTabDiagnostics to viewTabDiagnostics,
            btnTabSettings to viewTabSettings
        )

        fun selectTab(selectedBtn: Button, selectedView: ScrollView) {
            for ((btn, v) in tabs) {
                if (btn == selectedBtn) {
                    v.visibility = View.VISIBLE
                    btn.setTextColor(getColor(R.color.obito_primary))
                } else {
                    v.visibility = View.GONE
                    btn.setTextColor(getColor(R.color.obito_text_muted))
                }
            }
            if (selectedView == viewTabHistory) refreshHistoryList()
            if (selectedView == viewTabReader) refreshPermissionViews()
            if (selectedView == viewTabSettings) refreshSettingsView()
            if (selectedView == viewTabDiagnostics) refreshDiagnosticsView()
        }

        btnTabDashboard.setOnClickListener { selectTab(btnTabDashboard, viewTabDashboard) }
        btnTabReader.setOnClickListener { selectTab(btnTabReader, viewTabReader) }
        btnTabHistory.setOnClickListener { selectTab(btnTabHistory, viewTabHistory) }
        btnTabDiagnostics.setOnClickListener { selectTab(btnTabDiagnostics, viewTabDiagnostics) }
        btnTabSettings.setOnClickListener { selectTab(btnTabSettings, viewTabSettings) }
    }

    private fun setupDashboardControls() {
        switchDashboardMonitoring.setOnCheckedChangeListener { _, isChecked ->
            if (suppressSwitchCallback) return@setOnCheckedChangeListener
            if (isChecked) {
                if (!prefs.hasAcceptedConsent) {
                    setSwitchSilently(false)
                    showExplicitConsentDialog {
                        prefs.isMonitoringEnabled = true
                        setSwitchSilently(true)
                        AutoPaymentMonitorService.start(this)
                    }
                    return@setOnCheckedChangeListener
                }
                prefs.isMonitoringEnabled = true
                AutoPaymentMonitorService.start(this)
                tvDashboardServiceSubtitle.text = "bKash, Nagad ও Rocket রিডার চালু আছে"
                tvDashboardServiceSubtitle.setTextColor(getColor(R.color.status_green))
                Toast.makeText(this, "মনিটরিং সার্ভিস সক্রিয় করা হয়েছে", Toast.LENGTH_SHORT).show()
            } else {
                prefs.isMonitoringEnabled = false
                AutoPaymentMonitorService.stop(this)
                tvDashboardServiceSubtitle.text = "রিডার সার্ভিস বন্ধ আছে"
                tvDashboardServiceSubtitle.setTextColor(getColor(R.color.obito_text_muted))
                Toast.makeText(this, "মনিটরিং সার্ভিস বন্ধ করা হয়েছে", Toast.LENGTH_SHORT).show()
            }
        }

        btnQuickReconcile.setOnClickListener {
            btnQuickReconcile.isEnabled = false
            btnQuickReconcile.text = "ম্যাচ যাচাই হচ্ছে..."
            ioExecutor.execute {
                val result = repo.reconcileAllPayments()
                val pending = repo.syncDashboardMetrics()
                for (approvedEntry in result.newlyApprovedEntries) {
                    ObitoBroadcasts.postApprovedPaymentNotification(applicationContext, approvedEntry)
                }
                mainHandler.post {
                    btnQuickReconcile.isEnabled = true
                    btnQuickReconcile.text = "এখনই ম্যাচ ও ব্যালেন্স সিঙ্ক করুন"
                    tvStatPendingCount.text = pending.toString()
                    tvLastSyncSummary.text = result.summaryMessageBn
                    refreshMetricsAndRecentFeeds()
                    refreshHistoryList()
                    Toast.makeText(this, result.summaryMessageBn, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun setupReaderControls() {
        btnGrantReaderSms.setOnClickListener {
            requestSmsAndPostNotificationPermissions()
        }

        btnGrantReaderNotif.setOnClickListener {
            openNotificationListenerSettings()
        }

        btnRestrictedSettingsHelp.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Android 13 / 14 'Restricted Settings' সমাধান")
                .setMessage(
                    "Android 13 বা 14 ফোনে APK সরাসরি ইনস্টল করলে SMS বা Notification Access দেওয়ার সময় 'Restricted setting' দেখাতে পারে।\n\n" +
                        "সমাধানের সহজ নিয়ম:\n" +
                        "১. নিচের 'App Info খুলুন' বাটনে চাপ দিন।\n" +
                        "২. স্ক্রিনের ডানদিকের উপরে ৩-ডট (⋮) মেনুতে চাপ দিন।\n" +
                        "৩. 'Allow restricted settings' অপশনে চাপ দিয়ে ফোনের Fingerprint/PIN দিন।\n" +
                        "৪. এবার এই অ্যাপে ফিরে এসে SMS ও Notification Access চালু করুন।"
                )
                .setPositiveButton("App Info খুলুন") { _, _ ->
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.fromParts("package", packageName, null)
                    }
                    startActivity(intent)
                }
                .setNegativeButton("বন্ধ করুন", null)
                .show()
        }
    }

    private fun setupHistoryFilters() {
        val filterButtons = listOf(btnFilterAll, btnFilterApproved, btnFilterWaiting, btnFilterErrors)

        fun applyFilter(mode: String, activeBtn: Button) {
            currentFilterMode = mode
            for (btn in filterButtons) {
                if (btn == activeBtn) {
                    btn.setBackgroundResource(R.drawable.bg_tab_active)
                    btn.setTextColor(0xFFFFFFFF.toInt())
                } else {
                    btn.setBackgroundResource(R.drawable.bg_btn_outline)
                    btn.setTextColor(getColor(R.color.obito_text_muted))
                }
            }
            refreshHistoryList()
        }

        btnFilterAll.setOnClickListener { applyFilter("ALL", btnFilterAll) }
        btnFilterApproved.setOnClickListener { applyFilter("APPROVED", btnFilterApproved) }
        btnFilterWaiting.setOnClickListener { applyFilter("WAITING", btnFilterWaiting) }
        btnFilterErrors.setOnClickListener { applyFilter("ERRORS", btnFilterErrors) }
    }

    private fun setupDiagnosticsControls() {
        btnTestParseOnly.setOnClickListener {
            val raw = etSampleSms.text?.toString()?.trim().orEmpty()
            val sample = if (raw.isBlank()) {
                val s = "আপনি ০১৭১২৩৪৫৬৭৮ থেকে ৳২০.০০ পেয়েছেন। ফি ৳০.০০। ব্যালেন্স ৳৫২০.০০। TrxID DK451VVZYD at 04/11/2026 14:22"
                etSampleSms.setText(s)
                s
            } else raw

            val parsed = PaymentMessageParser.parseSampleForTest(sample)
            tvTestParseResult.visibility = View.VISIBLE
            if (parsed != null) {
                tvTestParseResult.setTextColor(getColor(R.color.status_green))
                tvTestParseResult.text = "✓ SMS পার্সার শনাক্ত সফল (Local Read-Only):\n" +
                    "Method: ${parsed.method.displayName}\n" +
                    "Amount: ৳${String.format(Locale.US, "%.2f", parsed.amount)}\n" +
                    "TrxID:  ${parsed.txIdNormalized}\n" +
                    "Sender: ${parsed.senderNumber.ifBlank { "N/A" }}"
            } else {
                tvTestParseResult.setTextColor(getColor(R.color.status_red))
                tvTestParseResult.text = "✕ সঠিক পেমেন্ট মেসেজ নয়।"
            }
        }

        btnDiagnoseServerMatch.setOnClickListener {
            val raw = etSampleSms.text?.toString()?.trim().orEmpty()
            btnDiagnoseServerMatch.isEnabled = false
            tvTestParseResult.visibility = View.VISIBLE
            tvTestParseResult.setTextColor(getColor(R.color.obito_navy))
            tvTestParseResult.text = "সিস্টেম ও ম্যাচ তথ্য যাচাই হচ্ছে..."

            ioExecutor.execute {
                val report = repo.diagnoseTrxIdReadOnly(raw)
                mainHandler.post {
                    btnDiagnoseServerMatch.isEnabled = true
                    tvTestParseResult.text = report
                }
            }
        }

        btnCopyDiagnostics.setOnClickListener {
            val text = tvDiagnosticLogs.text?.toString().orEmpty()
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            cm?.setPrimaryClip(ClipData.newPlainText("ObitoAutoPayDiag", text))
            Toast.makeText(this, "ডায়াগনস্টিক লগ কপি হয়েছে", Toast.LENGTH_SHORT).show()
        }

        btnClearDiagnostics.setOnClickListener {
            prefs.clearDiagnostics()
            prefs.clearCrashTrace()
            refreshDiagnosticsView()
            Toast.makeText(this, "লগ মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupSettingsControls() {
        btnReviewConsent.setOnClickListener {
            showExplicitConsentDialog()
        }

        btnDeactivateDevice.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("ডিভাইস সংযোগ বিচ্ছিন্ন করতে চান?")
                .setMessage("ডিভাইস ডি-অ্যাক্টিভেট করলে স্থানীয় কী ও সেশন মুছে যাবে এবং রিডার সার্ভিস বন্ধ হবে। পুনরায় সংযোগের জন্য Admin Panel থেকে নতুন কী নিতে হবে।")
                .setPositiveButton("Deactivate") { _, _ ->
                    ioExecutor.execute {
                        repo.deactivateDevice()
                        mainHandler.post {
                            AutoPaymentMonitorService.stop(this)
                            Toast.makeText(this, "ডিভাইস ডি-অ্যাক্টিভেট করা হয়েছে", Toast.LENGTH_SHORT).show()
                            refreshScreenMode()
                        }
                    }
                }
                .setNegativeButton("বাতিল", null)
                .show()
        }
    }

    private fun refreshMetricsAndRecentFeeds() {
        tvStatDetectedCount.text = prefs.detectedCount.toString()
        tvStatApprovedCount.text = prefs.approvedCount.toString()
        tvTodayAutoMoney.text = "৳ " + String.format(Locale.US, "%.2f", prefs.todayAmount)

        val det = prefs.detectedCount
        val app = prefs.approvedCount
        val rate = if (det > 0) ((app.toDouble() / det.toDouble()) * 100).toInt() else 100
        tvStatSuccessRate.text = "$rate%"

        setSwitchSilently(prefs.isMonitoringEnabled)
        tvDashboardServiceSubtitle.text = if (prefs.isMonitoringEnabled) {
            "bKash, Nagad ও Rocket রিডার চালু আছে"
        } else {
            "রিডার সার্ভিস বন্ধ আছে"
        }
        tvDashboardServiceSubtitle.setTextColor(if (prefs.isMonitoringEnabled) getColor(R.color.status_green) else getColor(R.color.obito_text_muted))

        // Populate Recent Activity on Dashboard
        val logs = prefs.getLogs()
        containerRecentActivity.removeAllViews()
        if (logs.isEmpty()) {
            tvEmptyRecentActivity.visibility = View.VISIBLE
            containerRecentActivity.visibility = View.GONE
        } else {
            tvEmptyRecentActivity.visibility = View.GONE
            containerRecentActivity.visibility = View.VISIBLE
            val inflater = LayoutInflater.from(this)
            for (entry in logs.take(4)) {
                containerRecentActivity.addView(renderPaymentLogItem(inflater, containerRecentActivity, entry))
            }
        }

        // Live Reader Feed in Tab 2
        containerLiveSmsList.removeAllViews()
        if (logs.isEmpty()) {
            tvEmptyLiveSms.visibility = View.VISIBLE
            containerLiveSmsList.visibility = View.GONE
        } else {
            tvEmptyLiveSms.visibility = View.GONE
            containerLiveSmsList.visibility = View.VISIBLE
            val inflater = LayoutInflater.from(this)
            for (entry in logs.take(15)) {
                containerLiveSmsList.addView(renderPaymentLogItem(inflater, containerLiveSmsList, entry))
            }
        }
    }

    private fun refreshHistoryList() {
        val allLogs = prefs.getLogs()
        val filtered = when (currentFilterMode) {
            "APPROVED" -> allLogs.filter { it.statusBadge == "APPROVED" }
            "WAITING" -> allLogs.filter { it.statusBadge.contains("WAITING") }
            "ERRORS" -> allLogs.filter { it.statusBadge in listOf("DUPLICATE", "MISMATCH", "ERROR") }
            else -> allLogs
        }

        containerHistoryList.removeAllViews()
        if (filtered.isEmpty()) {
            tvEmptyHistory.visibility = View.VISIBLE
            containerHistoryList.visibility = View.GONE
        } else {
            tvEmptyHistory.visibility = View.GONE
            containerHistoryList.visibility = View.VISIBLE
            val inflater = LayoutInflater.from(this)
            for (entry in filtered) {
                containerHistoryList.addView(renderPaymentLogItem(inflater, containerHistoryList, entry))
            }
        }
    }

    private fun renderPaymentLogItem(inflater: LayoutInflater, parent: LinearLayout, entry: PaymentLogEntry): View {
        val itemView = inflater.inflate(R.layout.item_payment_log, parent, false)
        val tvMethodAmount = itemView.findViewById<TextView>(R.id.tvMethodAmount)
        val tvOutcomeBadge = itemView.findViewById<TextView>(R.id.tvOutcomeBadge)
        val tvTrxAndSender = itemView.findViewById<TextView>(R.id.tvTrxAndSender)
        val tvDetailReason = itemView.findViewById<TextView>(R.id.tvDetailReason)

        tvMethodAmount.text = "${entry.method} • ৳${String.format(Locale.US, "%.2f", entry.amount)}"
        tvOutcomeBadge.text = entry.statusBadge

        val senderLabel = if (entry.senderNumber.isBlank()) "N/A" else entry.senderNumber
        tvTrxAndSender.text = "TrxID: ${entry.txId} • Sender: $senderLabel"

        val formattedTime = if (entry.timestampMillis > 0L) {
            timeFormat.format(Date(entry.timestampMillis))
        } else {
            "Just now"
        }
        val codeSuffix = if (entry.diagnosticCode.isNotBlank()) " • [${entry.diagnosticCode}]" else ""
        tvDetailReason.text = "${entry.detailNote}\nসময়: $formattedTime • উৎস: ${entry.sourceType}$codeSuffix"

        when (entry.statusBadge) {
            "APPROVED" -> {
                tvOutcomeBadge.setTextColor(getColor(R.color.status_green))
            }
            "DUPLICATE", "MISMATCH", "ERROR" -> {
                tvOutcomeBadge.setTextColor(getColor(R.color.status_red))
            }
            else -> {
                tvOutcomeBadge.setTextColor(getColor(R.color.status_amber))
            }
        }
        return itemView
    }

    private fun refreshPermissionViews() {
        if (hasSmsPermission()) {
            tvReaderSmsStatus.text = "SMS Permission: সক্রিয় ✓ (16247/16167/16216)"
            tvReaderSmsStatus.setTextColor(getColor(R.color.status_green))
            btnGrantReaderSms.text = "অনুমোদিত"
        } else {
            tvReaderSmsStatus.text = "SMS Permission: নিষ্ক্রিয়"
            tvReaderSmsStatus.setTextColor(getColor(R.color.obito_text_main))
            btnGrantReaderSms.text = "অনুমতি দিন"
        }

        if (isNotificationListenerEnabled()) {
            tvReaderNotifStatus.text = "Notification Access: সক্রিয় ✓"
            tvReaderNotifStatus.setTextColor(getColor(R.color.status_green))
            btnGrantReaderNotif.text = "অনুমোদিত"
        } else {
            tvReaderNotifStatus.text = "Notification Access: নিষ্ক্রিয়"
            tvReaderNotifStatus.setTextColor(getColor(R.color.obito_text_main))
            btnGrantReaderNotif.text = "সেটিংস খুলুন"
        }
    }

    private fun refreshDiagnosticsView() {
        val diagList = prefs.getDiagnostics()
        val crashTrace = prefs.lastFatalCrashTrace
        val crashMsg = prefs.lastFatalCrashMsg
        val crashTime = prefs.lastFatalCrashTime

        val sb = StringBuilder()
        if (crashTrace.isNotBlank()) {
            val t = if (crashTime > 0L) timeFormat.format(Date(crashTime)) else "Recently"
            sb.appendLine("🚨 [PREVIOUS FATAL CRASH DETECTED at $t]")
            sb.appendLine("Error: $crashMsg")
            sb.appendLine("Stack Trace:")
            sb.appendLine(crashTrace.trim())
            sb.appendLine("--------------------------------------------------")
        }

        if (diagList.isEmpty()) {
            if (crashTrace.isBlank()) {
                tvDiagnosticLogs.text = "কোনো ত্রুটি বা ডায়াগনস্টিক ইভেন্ট এখনো রেকর্ড হয়নি।"
                return
            }
        } else {
            for (d in diagList.take(30)) {
                val t = if (d.timestampMillis > 0L) shortTimeFormat.format(Date(d.timestampMillis)) else "--:--:--"
                val txPart = if (d.txId.isNotBlank()) " [${d.txId}]" else ""
                sb.appendLine("$t [${d.level}] ${d.code}$txPart: ${d.message}")
            }
        }
        tvDiagnosticLogs.text = sb.toString().trim()
    }

    private fun refreshSettingsView() {
        tvSettingDeviceId.text = prefs.deviceId
        tvSettingDeviceName.text = prefs.deviceName
        val k = prefs.activationKey
        tvSettingKeyUsed.text = if (k.length > 8) "${k.take(13)}****" else k
        val actAt = prefs.activationTimestamp
        tvSettingActivatedAt.text = if (actAt > 0L) timeFormat.format(Date(actAt)) else "Just now"
    }

    private fun setSwitchSilently(checked: Boolean) {
        suppressSwitchCallback = true
        switchDashboardMonitoring.isChecked = checked
        suppressSwitchCallback = false
    }

    private fun showExplicitConsentDialog(onAccepted: (() -> Unit)? = null) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.privacy_disclosure_title))
            .setMessage(getString(R.string.privacy_disclosure_body))
            .setCancelable(true)
            .setPositiveButton("আমি পড়েছি ও স্পষ্ট অনুমতি দিচ্ছি") { _, _ ->
                prefs.hasAcceptedConsent = true
                refreshPermissionViews()
                onAccepted?.invoke()
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun requestSmsAndPostNotificationPermissions() {
        val needed = mutableListOf(
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_SMS
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        requestPermissions(needed.toTypedArray(), REQ_CODE_PERMISSIONS)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_CODE_PERMISSIONS) {
            refreshPermissionViews()
        }
    }

    private fun openNotificationListenerSettings() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (_: Exception) {
            Toast.makeText(this, "Settings -> Notification Access থেকে চালু করুন", Toast.LENGTH_LONG).show()
        }
    }

    private fun hasSmsPermission(): Boolean {
        return try {
            checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
        } catch (_: Throwable) {
            false
        }
    }

    private fun isNotificationListenerEnabled(): Boolean {
        return try {
            val cn = ComponentName(this, PaymentNotificationListenerService::class.java)
            val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
            flat.contains(cn.flattenToString()) || flat.contains(cn.flattenToShortString())
        } catch (_: Throwable) {
            false
        }
    }
}
