package com.obitomart.autopayment

import android.Manifest
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import com.obitomart.autopayment.model.PaymentLogEntry
import com.obitomart.autopayment.ui.MainActivity
import java.util.Locale

object ObitoBroadcasts {
    const val ACTION_LOG_UPDATED = "com.obitomart.autopayment.ACTION_LOG_UPDATED"

    fun notifyUiLogUpdated(context: Context) {
        val intent = Intent(ACTION_LOG_UPDATED).apply {
            setPackage(context.packageName)
        }
        context.sendBroadcast(intent)
    }

    @Suppress("DEPRECATION")
    fun postApprovedPaymentNotification(context: Context, entry: PaymentLogEntry) {
        if (entry.statusBadge != "APPROVED") return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val piFlags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val pendingIntent = PendingIntent.getActivity(context, 2001, openIntent, piFlags)

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(context, ObitoAutoPayApp.CHANNEL_ALERTS)
        } else {
            Notification.Builder(context)
        }

        val amountFormatted = String.format(Locale.US, "%.2f", entry.amount)
        val notification = builder
            .setSmallIcon(R.drawable.ic_stat_autopay)
            .setContentTitle("Auto-Approved: ${entry.method} ৳$amountFormatted")
            .setContentText("TrxID: ${entry.txId} • ইউজারের ব্যালেন্সে যোগ হয়েছে")
            .setStyle(
                Notification.BigTextStyle().bigText(
                    "TrxID: ${entry.txId}\nমাধ্যম: ${entry.method} • পরিমাণ: ৳$amountFormatted\n${entry.detailNote}"
                )
            )
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            nm?.notify(entry.txId.hashCode(), notification)
        } catch (_: SecurityException) {
            // Ignore if notification permission was revoked
        }
    }
}
