package com.obitomart.autopayment.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.obitomart.autopayment.data.AutoPaymentPrefs
import com.obitomart.autopayment.service.AutoPaymentMonitorService

/**
 * Resumes monitoring after phone reboot ONLY IF the Admin previously accepted
 * the privacy consent, turned monitoring ON, and has an active Admin session.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        val ctx = context ?: return
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return

        val prefs = AutoPaymentPrefs(ctx)
        if (prefs.hasAcceptedConsent && prefs.isMonitoringEnabled && prefs.isSignedIn) {
            AutoPaymentMonitorService.start(ctx)
        }
    }
}
