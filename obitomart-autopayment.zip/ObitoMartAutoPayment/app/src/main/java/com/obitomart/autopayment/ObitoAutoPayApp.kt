package com.obitomart.autopayment

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

import android.content.Context
import android.util.Log
import java.io.PrintWriter
import java.io.StringWriter

class ObitoAutoPayApp : Application() {

    companion object {
        private const val TAG = "ObitoAutoPayApp"
        const val CHANNEL_MONITOR = "obito_autopay_monitor"
        const val CHANNEL_ALERTS = "obito_autopay_alerts"
    }

    override fun onCreate() {
        super.onCreate()
        setupGlobalCrashHandler()
        createNotificationChannels()
    }

    private fun setupGlobalCrashHandler() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                Log.e(TAG, "FATAL CRASH on thread ${thread.name}: ${throwable.message}", throwable)
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val stackTrace = sw.toString()

                val prefs = getSharedPreferences("obito_autopay_prefs", Context.MODE_PRIVATE)
                prefs.edit()
                    .putString("last_fatal_crash_msg", throwable.localizedMessage ?: throwable.javaClass.simpleName)
                    .putString("last_fatal_crash_trace", stackTrace)
                    .putLong("last_fatal_crash_time", System.currentTimeMillis())
                    .apply()
            } catch (e: Throwable) {
                Log.e(TAG, "Failed to persist crash info", e)
            } finally {
                defaultHandler?.uncaughtException(thread, throwable)
            }
        }
    }

    private fun createNotificationChannels() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val manager = getSystemService(NotificationManager::class.java) ?: return

                val monitorChannel = NotificationChannel(
                    CHANNEL_MONITOR,
                    "Auto-Payment Active Monitor",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Shows when OBITO MART Auto-Payment listener is active"
                }

                val alertsChannel = NotificationChannel(
                    CHANNEL_ALERTS,
                    "Verified Payment Alerts",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "Notifies Admin when a bKash, Nagad, or Rocket payment is auto-approved"
                }

                manager.createNotificationChannel(monitorChannel)
                manager.createNotificationChannel(alertsChannel)
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Could not create notification channels: ${e.message}")
        }
    }
}
