package com.obitomart.autopayment.service

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.obitomart.autopayment.ObitoBroadcasts
import com.obitomart.autopayment.data.AutoPaymentPrefs
import com.obitomart.autopayment.data.MysqlAutoPaymentRepository
import com.obitomart.autopayment.parser.PaymentMessageParser
import java.util.concurrent.Executors

/**
 * Listens ONLY to payment notifications from official bKash, Nagad, Rocket apps
 * or MFS SMS notifications — strictly after explicit Admin consent and active toggle.
 */
class PaymentNotificationListenerService : NotificationListenerService() {

    private val worker = Executors.newSingleThreadExecutor()

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val notification = sbn ?: return
        if (notification.packageName == packageName) return

        val prefs = AutoPaymentPrefs(applicationContext)
        if (!prefs.hasAcceptedConsent || !prefs.isMonitoringEnabled) {
            return
        }

        val extras = notification.notification?.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()

        // Privacy Gate 1: Immediately ignore all non-MFS / non-MFS-SMS packages
        if (!PaymentMessageParser.isEligibleNotificationPackage(notification.packageName, title)) {
            return
        }

        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
        val regularText = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
        val body = if (!bigText.isNullOrBlank()) bigText else regularText

        // Privacy Gate 2: Extract structured incoming payment only (rejects OTPs/PINs/outgoing)
        val parsed = PaymentMessageParser.parseNotification(
            packageName = notification.packageName,
            title = title,
            text = body
        ) ?: return

        synchronized(LOCK) {
            if (prefs.hasProcessedHashRecently(parsed.messageHash)) {
                return
            }
            prefs.markHashProcessed(parsed.messageHash)
        }

        val appCtx = applicationContext
        worker.execute {
            val repo = MysqlAutoPaymentRepository(appCtx)
            val entry = repo.processIncomingPayment(parsed)
            ObitoBroadcasts.notifyUiLogUpdated(appCtx)
            ObitoBroadcasts.postApprovedPaymentNotification(appCtx, entry)
            if (entry.statusBadge == "WAITING" || entry.statusBadge == "ERROR") {
                AutoPaymentMonitorService.triggerRapidReconcile(appCtx)
            } else {
                AutoPaymentMonitorService.start(appCtx)
            }
        }
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    companion object {
        private val LOCK = Any()
    }
}
