package com.obitomart.autopayment.data

import android.content.Context
import android.os.Build
import android.util.Log
import com.obitomart.autopayment.model.DiagnosticLogEntry
import com.obitomart.autopayment.model.PaymentLogEntry
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class AutoPaymentPrefs(context: Context) {

    companion object {
        private const val TAG = "ObitoAutoPay"
    }

    private val prefs = context.getSharedPreferences("obito_autopay_prefs", Context.MODE_PRIVATE)

    var hasAcceptedConsent: Boolean
        get() = prefs.getBoolean("has_accepted_consent", false)
        set(value) = prefs.edit().putBoolean("has_accepted_consent", value).apply()

    var isMonitoringEnabled: Boolean
        get() = prefs.getBoolean("is_monitoring_enabled", false)
        set(value) = prefs.edit().putBoolean("is_monitoring_enabled", value).apply()

    // Activation Key & MySQL API Session
    var activationKey: String
        get() = prefs.getString("activation_key", "") ?: ""
        set(value) = prefs.edit().putString("activation_key", value).apply()

    var sessionToken: String
        get() = prefs.getString("session_token", "") ?: ""
        set(value) = prefs.edit().putString("session_token", value).apply()

    // ByetHost browser-verification cookie; stored separately from the device session.
    var byetHostCookie: String
        get() = prefs.getString("byet_host_cookie", "") ?: ""
        set(value) = prefs.edit().putString("byet_host_cookie", value).apply()

    var websiteApiUrl: String
        get() = prefs.getString("website_api_url", "") ?: ""
        set(value) = prefs.edit().putString("website_api_url", value).apply()

    var pendingWebsiteCredits: String
        get() = prefs.getString("pending_website_credits", "[]") ?: "[]"
        set(value) = prefs.edit().putString("pending_website_credits", value).apply()

    var activationTimestamp: Long
        get() = prefs.getLong("activation_timestamp", 0L)
        set(value) = prefs.edit().putLong("activation_timestamp", value).apply()

    var deviceStatus: String
        get() = prefs.getString("device_status", "standby") ?: "standby"
        set(value) = prefs.edit().putString("device_status", value).apply()

    var authToken: String
        get() = prefs.getString("auth_token", "") ?: ""
        set(value) = prefs.edit().putString("auth_token", value).apply()

    var authRefreshToken: String
        get() = prefs.getString("auth_refresh_token", "") ?: ""
        set(value) = prefs.edit().putString("auth_refresh_token", value).apply()

    var authUid: String
        get() = prefs.getString("auth_uid", "") ?: ""
        set(value) = prefs.edit().putString("auth_uid", value).apply()

    var authTokenExpiryMs: Long
        get() = prefs.getLong("auth_token_expiry_ms", 0L)
        set(value) = prefs.edit().putLong("auth_token_expiry_ms", value).apply()

    val isDeviceActivated: Boolean
        get() = activationKey.isNotBlank() && sessionToken.isNotBlank() && deviceStatus != "revoked"

    val isSignedIn: Boolean
        get() = isDeviceActivated

    fun clearActivationSession() {
        prefs.edit()
            .remove("activation_key")
            .remove("session_token")
            .remove("website_api_url")
            .remove("pending_website_credits")
            .remove("activation_timestamp")
            .remove("auth_token")
            .remove("auth_refresh_token")
            .remove("auth_uid")
            .remove("auth_token_expiry_ms")
            .putString("device_status", "revoked")
            .putBoolean("is_monitoring_enabled", false)
            .apply()
    }

    fun clearAuthSession() {
        clearActivationSession()
    }

    var lastFatalCrashMsg: String
        get() = prefs.getString("last_fatal_crash_msg", "") ?: ""
        set(value) = prefs.edit().putString("last_fatal_crash_msg", value).apply()

    var lastFatalCrashTrace: String
        get() = prefs.getString("last_fatal_crash_trace", "") ?: ""
        set(value) = prefs.edit().putString("last_fatal_crash_trace", value).apply()

    var lastFatalCrashTime: Long
        get() = prefs.getLong("last_fatal_crash_time", 0L)
        set(value) = prefs.edit().putLong("last_fatal_crash_time", value).apply()

    fun clearCrashTrace() {
        prefs.edit()
            .remove("last_fatal_crash_msg")
            .remove("last_fatal_crash_trace")
            .remove("last_fatal_crash_time")
            .apply()
    }

    var detectedCount: Int
        get() = prefs.getInt("detected_count", 0)
        set(value) = prefs.edit().putInt("detected_count", value).apply()

    var todayAmount: Double
        get() = prefs.getFloat("today_amount", 0f).toDouble()
        set(value) = prefs.edit().putFloat("today_amount", value.toFloat()).apply()

    var approvedCount: Int
        get() = prefs.getInt("approved_count", 0)
        set(value) = prefs.edit().putInt("approved_count", value).apply()

    var verificationMode: String
        get() = "ADMIN_TRANSACTION"
        set(_) {}

    val deviceId: String
        get() {
            var existing = prefs.getString("device_id", null)
            if (existing.isNullOrBlank()) {
                existing = "android_" + UUID.randomUUID().toString().take(8)
                prefs.edit().putString("device_id", existing).apply()
            }
            return existing
        }

    val deviceName: String
        get() = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"

    fun hasProcessedHashRecently(hash: String): Boolean {
        val raw = prefs.getString("recent_hashes", "") ?: ""
        return raw.split("|").contains(hash)
    }

    fun markHashProcessed(hash: String) {
        val current = (prefs.getString("recent_hashes", "") ?: "")
            .split("|")
            .filter { it.isNotBlank() }
            .toMutableList()
        if (!current.contains(hash)) {
            current.add(0, hash)
        }
        val trimmed = current.take(100).joinToString("|")
        prefs.edit().putString("recent_hashes", trimmed).apply()
    }

    @Synchronized
    fun appendLog(entry: PaymentLogEntry): Boolean {
        val current = getLogs().toMutableList()
        val existingApproved = current.firstOrNull { it.txId == entry.txId && it.statusBadge == "APPROVED" }
        if (existingApproved != null && entry.statusBadge == "WAITING") {
            return false
        }

        val existingSame = current.firstOrNull { it.txId == entry.txId }
        if (existingSame != null &&
            existingSame.statusBadge == entry.statusBadge &&
            existingSame.detailNote == entry.detailNote &&
            existingSame.diagnosticCode == entry.diagnosticCode
        ) {
            return false
        }

        current.removeAll {
            it.txId == entry.txId && it.statusBadge != "APPROVED"
        }
        current.add(0, entry)

        val arr = JSONArray()
        for (item in current.take(60)) {
            arr.put(
                JSONObject().apply {
                    put("txId", item.txId)
                    put("method", item.method)
                    put("amount", item.amount)
                    put("senderNumber", item.senderNumber)
                    put("sourceType", item.sourceType)
                    put("statusBadge", item.statusBadge)
                    put("detailNote", item.detailNote)
                    put("timestampMillis", item.timestampMillis)
                    put("diagnosticCode", item.diagnosticCode)
                }
            )
        }
        prefs.edit().putString("payment_logs_json", arr.toString()).apply()
        return true
    }

    fun getLogs(): List<PaymentLogEntry> {
        val raw = prefs.getString("payment_logs_json", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val list = ArrayList<PaymentLogEntry>(arr.length())
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    PaymentLogEntry(
                        txId = obj.optString("txId", ""),
                        method = obj.optString("method", ""),
                        amount = obj.optDouble("amount", 0.0),
                        senderNumber = obj.optString("senderNumber", ""),
                        sourceType = obj.optString("sourceType", ""),
                        statusBadge = obj.optString("statusBadge", "WAITING"),
                        detailNote = obj.optString("detailNote", ""),
                        timestampMillis = obj.optLong("timestampMillis", 0L),
                        diagnosticCode = obj.optString("diagnosticCode", "")
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun appendDiagnostic(level: String, code: String, txId: String, message: String) {
        val logLine = "[$code] txId=${txId.ifBlank { "-" }} | $message"
        when (level) {
            "ERROR" -> Log.e(TAG, logLine)
            "WARN" -> Log.w(TAG, logLine)
            else -> Log.i(TAG, logLine)
        }

        val current = getDiagnostics().toMutableList()
        val latestForTx = current.firstOrNull { it.txId == txId && it.code == code }
        if (latestForTx != null && latestForTx.message == message &&
            (System.currentTimeMillis() - latestForTx.timestampMillis) < 60_000L
        ) {
            return
        }

        current.add(
            0,
            DiagnosticLogEntry(
                timestampMillis = System.currentTimeMillis(),
                level = level,
                code = code,
                txId = txId,
                message = message
            )
        )

        val arr = JSONArray()
        for (item in current.take(60)) {
            arr.put(
                JSONObject().apply {
                    put("timestampMillis", item.timestampMillis)
                    put("level", item.level)
                    put("code", item.code)
                    put("txId", item.txId)
                    put("message", item.message)
                }
            )
        }
        prefs.edit().putString("diagnostic_logs_json", arr.toString()).apply()
    }

    fun getDiagnostics(): List<DiagnosticLogEntry> {
        val raw = prefs.getString("diagnostic_logs_json", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val list = ArrayList<DiagnosticLogEntry>(arr.length())
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    DiagnosticLogEntry(
                        timestampMillis = obj.optLong("timestampMillis", 0L),
                        level = obj.optString("level", "INFO"),
                        code = obj.optString("code", ""),
                        txId = obj.optString("txId", ""),
                        message = obj.optString("message", "")
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun clearDiagnostics() {
        prefs.edit().remove("diagnostic_logs_json").apply()
    }
}
