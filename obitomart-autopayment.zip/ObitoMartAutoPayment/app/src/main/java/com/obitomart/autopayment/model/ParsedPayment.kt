package com.obitomart.autopayment.model

enum class PaymentMethod(val id: String, val displayName: String) {
    BKASH("bkash", "bKash"),
    NAGAD("nagad", "Nagad"),
    ROCKET("rocket", "Rocket");

    companion object {
        fun fromString(raw: String?): PaymentMethod? {
            if (raw.isNullOrBlank()) return null
            val s = raw.trim()
                .lowercase()
                .replace("\u09af\u09bc", "\u09df") // normalize decomposed য় -> য়
                .replace(Regex("[\\u200B-\\u200F\\uFEFF]"), "")
            val cleanDigits = s.replace(Regex("[^0-9]"), "")
            return when {
                s.contains("bkash") ||
                    s.contains("bikash") ||
                    s.contains("b-kash") ||
                    s.contains("b kash") ||
                    s.contains("বিকাশ") ||
                    cleanDigits == "16247" ||
                    cleanDigits.endsWith("16247") -> BKASH

                s.contains("nagad") ||
                    s.contains("nogod") ||
                    s.contains("nagod") ||
                    s.contains("n-gad") ||
                    s.contains("নগদ") ||
                    s.contains("নগাদ") ||
                    cleanDigits == "16167" ||
                    cleanDigits.endsWith("16167") -> NAGAD

                s.contains("rocket") ||
                    s.contains("roket") ||
                    s.contains("dbbl") ||
                    s.contains("dutch-bangla") ||
                    s.contains("dutch bangla") ||
                    s.contains("dutchbangla") ||
                    s.contains("রকেট") ||
                    s.contains("ডাচ-বাংলা") ||
                    s.contains("ডাচ বাংলা") ||
                    cleanDigits == "16216" ||
                    cleanDigits.endsWith("16216") -> ROCKET

                else -> null
            }
        }
    }
}

data class ParsedPayment(
    val method: PaymentMethod,
    val amount: Double,
    val txIdNormalized: String,
    val senderNumber: String,
    val sourceType: String, // "SMS", "NOTIFICATION", "SYNC", "LOCAL_TEST"
    val messageHash: String,
    val detectedAtMillis: Long = System.currentTimeMillis()
)

data class PaymentLogEntry(
    val txId: String,
    val method: String,
    val amount: Double,
    val senderNumber: String,
    val sourceType: String,
    val statusBadge: String, // "APPROVED", "WAITING", "MISMATCH", "DUPLICATE", "ERROR", "AUTH NEEDED"
    val detailNote: String,
    val timestampMillis: Long,
    val diagnosticCode: String = ""
)

data class DiagnosticLogEntry(
    val timestampMillis: Long,
    val level: String, // "INFO", "WARN", "ERROR"
    val code: String,
    val txId: String,
    val message: String
)

data class ReconciliationResult(
    val approvedCount: Int,
    val checkedPendingCount: Int,
    val unmatchedIncomingCount: Int,
    val mismatchCount: Int,
    val duplicateCount: Int,
    val errorCount: Int,
    val summaryMessageBn: String,
    val newlyApprovedEntries: List<PaymentLogEntry> = emptyList(),
    val logsChanged: Boolean = false
)
