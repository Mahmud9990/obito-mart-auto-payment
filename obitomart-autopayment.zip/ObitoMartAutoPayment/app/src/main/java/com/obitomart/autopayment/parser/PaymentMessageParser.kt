package com.obitomart.autopayment.parser

import com.obitomart.autopayment.model.ParsedPayment
import com.obitomart.autopayment.model.PaymentMethod
import java.security.MessageDigest
import kotlin.math.abs

/**
 * Strict, privacy-preserving parser and normalizer for Bangladeshi MFS payment messages
 * (bKash, Nagad, Rocket).
 *
 * Security & Privacy Rules:
 * 1. Only inspects allowlisted MFS packages / official sender IDs.
 * 2. Immediately discards OTP, PIN, verification codes, personal chats, and outgoing transfers.
 * 3. Normalizes Bengali digits (০-৯), Unicode nukta forms (পেয়েছেন/পেয়েছেন), and formatted numbers.
 * 4. Computes a one-way SHA-256 hash so raw SMS text is NEVER sent to or stored on the server.
 */
object PaymentMessageParser {

    private val MFS_APP_PACKAGES = mapOf(
        "com.bKash.customerapp" to PaymentMethod.BKASH,
        "com.bKash.merchantapp" to PaymentMethod.BKASH,
        "com.konasl.nagad" to PaymentMethod.NAGAD,
        "com.konasl.nagad.merchant" to PaymentMethod.NAGAD,
        "com.konasl.nagad.agent" to PaymentMethod.NAGAD,
        "com.dbbl.mbs.apps.main" to PaymentMethod.ROCKET
    )

    private val SMS_APP_PACKAGES = setOf(
        "com.google.android.apps.messaging",
        "com.android.mms",
        "com.android.messaging",
        "com.samsung.android.messaging",
        "com.miui.mms",
        "com.coloros.mms",
        "com.oppo.mms",
        "com.vivo.message",
        "com.oneplus.mms",
        "com.transsion.smartmessage",
        "com.nothing.mms"
    )

    private val SENSITIVE_OTP_PATTERNS = Regex(
        "(?i)\\b(otp|verification\\s*code|security\\s*code|secret\\s*pin|one\\s*time\\s*password|do\\s*not\\s*share|গোপন\\s*পিন|ওটিপি|ভেরিফিকেশন\\s*কোড)\\b"
    )

    private val OUTGOING_PATTERNS = Regex(
        "(?i)(send\\s*money\\s*(?:tk\\.?|bdt|৳)?\\s*[0-9,.]+\\s*to|cash\\s*out\\s*(?:tk\\.?|bdt|৳)|mobile\\s*recharge\\s*(?:tk\\.?|bdt|৳)|payment\\s*(?:tk\\.?|bdt|৳)?\\s*[0-9,.]+\\s*to|bill\\s*pay\\s*(?:tk\\.?|bdt|৳)|টাকা\\s*পাঠানো\\s*হয়েছে|ক্যাশ\\s*আউট\\s*সফল)"
    )

    private val INCOMING_KEYWORDS = Regex(
        "(?i)(" +
            "you\\s*have\\s*received|" +
            "money\\s*received|" +
            "payment\\s*(?:received|of)|" +
            "cash[- ]?in\\s*(?:of|received|tk|bdt|৳|[0-9])|" +
            "cash[- ]?in\\b|" +
            "received\\s*(?:tk\\.?|bdt|৳|payment|money)|" +
            "(?:tk\\.?|bdt|৳)\\s*[0-9,.]+\\s*(?:received|has\\s*been\\s*credited|credited)|" +
            "credited\\s*(?:to|with)|" +
            "deposit\\s*of|" +
            "পেয়েছেন|" +
            "ক্যাশ\\s*ইন|" +
            "মানি\\s*রিসিভড|" +
            "রিসিভ\\s*হয়েছে|" +
            "গ্রহণ\\s*(?:করেছেন|করা\\s*হয়েছে)|" +
            "জমা\\s*হয়েছে" +
            ")"
    )

    // Amount patterns supporting Tk, BDT, ৳, টাকা, Bengali digits (already converted to 0-9), integers & decimals
    private val AMOUNT_PATTERNS = listOf(
        // Common Nagad format: "Amount: Tk 750.00" (also accepts currency after the number)
        Regex("(?i)(?:amount|পরিমাণ)\\s*:?\\s*(?:(?:tk\\.?|bdt|৳|টাকা)\\s*)?([0-9,]+(?:\\.[0-9]{1,2})?)(?:\\s*(?:tk\\.?|bdt|৳|টাকা))?"),
        Regex("(?i)(?:received(?:\\s+payment)?|cash[- ]?in(?:\\s+of)?(?:\\s+received)?|money\\s*received(?:\\s+of)?|payment(?:\\s+of)?(?:\\s+received)?|ক্যাশ\\s*ইন|amount\\s*:?|পরিমাণ\\s*:?)\\s*(?:tk\\.?|bdt|৳|টাকা)\\s*([0-9,]+(?:\\.[0-9]{1,2})?)"),
        Regex("(?i)(?:tk\\.?|bdt|৳|টাকা)\\s*([0-9,]+(?:\\.[0-9]{1,2})?)\\s*(?:received|credited|has\\s*been\\s*credited|পেয়েছেন|সফল|গ্রহণ|রিসিভ|জমা|cash[- ]?in|ক্যাশ\\s*ইন)"),
        Regex("(?i)(?:deposit\\s*of|credited\\s*with)\\s*(?:tk\\.?|bdt|৳|টাকা)\\s*([0-9,]+(?:\\.[0-9]{1,2})?)"),
        Regex("(?i)(?:amount\\s*:|পরিমাণ\\s*:?)\\s*([0-9,]+(?:\\.[0-9]{1,2})?)\\s*(?:tk\\.?|bdt|৳|টাকা)?"),
        Regex("(?i)([0-9,]+(?:\\.[0-9]{1,2})?)\\s*(?:tk\\.?|bdt|৳|টাকা)\\s*(?:received|পেয়েছেন|ক্যাশ\\s*ইন|রিসিভ)"),
        Regex("(?i)(?:from|থেকে|হতে)\\s+[0-9*Xx•+\\-\\s]{9,17}\\s+(?:৳|tk\\.?|bdt|টাকা)\\s*([0-9,]+(?:\\.[0-9]{1,2})?)"),
        Regex("(?i)(?:থেকে|হতে)\\s*(?:৳|tk\\.?|bdt|টাকা)\\s*([0-9,]+(?:\\.[0-9]{1,2})?)")
    )

    // TrxID patterns: bKash ("TrxID DK451VVZYD"), Nagad ("TxnID: 72N98K1L"), Rocket ("TxnId: 4829103847" or "TxnId:4829103847")
    private val TRX_ID_PATTERN = Regex(
        "(?i)(?:\\btrx\\s*id|\\btrxid|\\btxn\\s*id|\\btxnid|\\btrans(?:action)?\\s*id|\\btrans\\s*id|ট্রানজেকশন\\s*আইডি|টিআরএক্সআইডি)\\s*[:#\\-=]?\\s*([A-Z0-9]{5,24})\\b"
    )

    // Sender account/mobile patterns supporting optional +88/88, hyphens/spaces, 11-digit MFS, 12-digit Rocket, and masked digits
    private val SENDER_PATTERNS = listOf(
        Regex("(?i)(?:from\\s*(?:a/c\\s*:?)?|a/c\\s*:|sender\\s*:?|uddokta\\s*:?|agent\\s*:?|customer\\s*:?|প্রেরক\\s*:?|উদ্যোক্তা\\s*:?|এজেন্ট\\s*:?)\\s*(?:\\+?88)?\\s*(01[3-9][0-9*Xx•\\-\\s]{7,12})"),
        Regex("(?:থেকে|হতে)\\s*(?:\\+?88)?\\s*(01[3-9][0-9*Xx•\\-\\s]{7,12})"),
        Regex("(?:\\+?88)?(01[3-9][0-9*Xx•\\-]{7,11})\\s*(?:থেকে|হতে)")
    )

    /**
     * Check if notification package is eligible for inspection at all.
     * Non-MFS / non-SMS packages (WhatsApp, Messenger, Gmail, Banking OTPs, etc.) return false immediately.
     */
    fun isEligibleNotificationPackage(packageName: String, notificationTitle: String?): Boolean {
        if (MFS_APP_PACKAGES.containsKey(packageName)) return true
        if (SMS_APP_PACKAGES.contains(packageName)) {
            return detectMethodFromSender(notificationTitle ?: "") != null
        }
        return false
    }

    /**
     * Identify payment method strictly from official SMS sender address / notification title.
     */
    fun detectMethodFromSender(senderOrTitle: String): PaymentMethod? {
        return PaymentMethod.fromString(senderOrTitle)
    }

    /**
     * Normalize any user-entered or stored Transaction ID (TrxID / TxnID).
     * Handles:
     * - Lowercase / whitespace / invisible zero-width Unicode chars
     * - Bengali digits (০-৯ -> 0-9)
     * - Pasted prefixes like "TrxID DK451VVZYD", "TrxID: DK451VVZYD", "TxnID-72N98K1L", or full SMS paste!
     */
    fun normalizeTrxId(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        val cleaned = normalizeBengaliText(raw).trim()
        val matchInText = TRX_ID_PATTERN.find(cleaned)
        if (matchInText != null) {
            return matchInText.groupValues[1].uppercase().replace(Regex("[^A-Z0-9]"), "")
        }

        val strippedPrefix = cleaned.replace(
            Regex("^(?i)(?:trxid|txnid|trans(?:action)?\\s*id|trx\\s*id|ট্রানজেকশন\\s*আইডি)\\s*[:#\\-=\\s]+"),
            ""
        )
        return strippedPrefix.uppercase().replace(Regex("[^A-Z0-9]"), "")
    }

    /**
     * Normalize a sender phone/account string while preserving mask symbols (*, X) if present.
     * Strips +88 / leading 88, spaces, hyphens, and converts Bengali digits to ASCII 0-9.
     */
    fun normalizeSenderPreservingMask(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        var s = normalizeBengaliText(raw)
            .replace('•', '*')
            .replace(Regex("[^0-9*Xx]"), "")
            .uppercase()

        if (s.startsWith("8801") && s.length >= 12) {
            s = s.substring(2)
        } else if (s.length == 10 && s[0] == '1' && s[1] in '3'..'9') {
            s = "0$s"
        }
        return s
    }

    /**
     * Parse numeric amount safely from string/number (supports Bengali digits, commas, Tk/৳ symbols).
     */
    fun parseFlexibleAmount(raw: String?): Double {
        if (raw.isNullOrBlank()) return 0.0
        val cleaned = normalizeBengaliText(raw)
            .replace(Regex("[^0-9.]"), "")
        return cleaned.toDoubleOrNull() ?: 0.0
    }

    /**
     * Check if arbitrary text contains identifiable MFS signature keywords or TrxID patterns.
     */
    fun hasMfsSignature(text: String): Boolean {
        if (text.isBlank()) return false
        val norm = normalizeBengaliText(text)
        return norm.contains("bkash", ignoreCase = true) ||
            norm.contains("bikash", ignoreCase = true) ||
            norm.contains("বিকাশ") ||
            norm.contains("nagad", ignoreCase = true) ||
            norm.contains("নগদ") ||
            norm.contains("nogod", ignoreCase = true) ||
            norm.contains("rocket", ignoreCase = true) ||
            norm.contains("রকেট") ||
            norm.contains("dbbl", ignoreCase = true) ||
            norm.contains("trxid", ignoreCase = true) ||
            norm.contains("txnid", ignoreCase = true) ||
            norm.contains("uddokta", ignoreCase = true) ||
            norm.contains("cash-in", ignoreCase = true) ||
            norm.contains("cash in", ignoreCase = true) ||
            TRX_ID_PATTERN.containsMatchIn(norm)
    }

    /**
     * Parse incoming SMS message. Resolves provider from sender address, or falls back to message body.
     */
    fun parseSms(senderAddress: String, rawBody: String): ParsedPayment? {
        val method = detectMethodFromSender(senderAddress)
            ?: detectMethodFromSender(rawBody)
            ?: parseSampleForTest(rawBody)?.method
            ?: return null
        return parseInternal(method, rawBody, "SMS")
    }

    /**
     * Parse status-bar notification from official bKash/Nagad/Rocket app or default SMS app.
     */
    fun parseNotification(packageName: String, title: String?, text: String?): ParsedPayment? {
        val method = MFS_APP_PACKAGES[packageName]
            ?: if (SMS_APP_PACKAGES.contains(packageName)) detectMethodFromSender(title ?: "") else null
        if (method == null) return null

        val combined = buildString {
            if (!title.isNullOrBlank()) append(title).append(" ")
            if (!text.isNullOrBlank()) append(text)
        }.trim()

        if (combined.isBlank()) return null
        return parseInternal(method, combined, "NOTIFICATION")
    }

    /**
     * Parse sample text for local self-testing / read-only diagnostic check on Admin's phone.
     */
    fun parseSampleForTest(rawText: String, explicitMethodHint: PaymentMethod? = null): ParsedPayment? {
        val normalizedText = normalizeBengaliText(rawText)
        val inferredMethod = explicitMethodHint
            ?: detectMethodFromSender(normalizedText)
            ?: when {
                normalizedText.contains("TxnId:", ignoreCase = true) && normalizedText.contains("A/C", ignoreCase = true) -> PaymentMethod.ROCKET
                normalizedText.contains("TxnID", ignoreCase = true) || normalizedText.contains("Uddokta", ignoreCase = true) -> PaymentMethod.NAGAD
                normalizedText.contains("TrxID", ignoreCase = true) -> PaymentMethod.BKASH
                normalizedText.contains("rocket", ignoreCase = true) || normalizedText.contains("রকেট") || normalizedText.contains("dbbl", ignoreCase = true) -> PaymentMethod.ROCKET
                normalizedText.contains("nagad", ignoreCase = true) || normalizedText.contains("নগদ") -> PaymentMethod.NAGAD
                normalizedText.contains("bkash", ignoreCase = true) || normalizedText.contains("বিকাশ") -> PaymentMethod.BKASH
                else -> null
            } ?: return null

        return parseInternal(inferredMethod, rawText, "LOCAL_TEST")
    }

    private fun parseInternal(
        method: PaymentMethod,
        rawMessage: String,
        sourceType: String
    ): ParsedPayment? {
        val normalized = normalizeBengaliText(rawMessage).trim()
        if (normalized.length < 12) return null

        // 1. Privacy & Security Gate: Never parse OTPs, PINs, or outgoing transfers
        if (SENSITIVE_OTP_PATTERNS.containsMatchIn(normalized)) return null
        if (OUTGOING_PATTERNS.containsMatchIn(normalized)) return null
        if (!INCOMING_KEYWORDS.containsMatchIn(normalized)) return null

        // 2. Extract Transaction ID
        val trxMatch = TRX_ID_PATTERN.find(normalized) ?: return null
        val txIdNormalized = trxMatch.groupValues[1].trim().uppercase().replace(Regex("[^A-Z0-9]"), "")
        if (txIdNormalized.length < 5) return null

        // 3. Extract Incoming Amount (must be > 0, distinct from Fee/Balance)
        var parsedAmount: Double? = null
        for (pattern in AMOUNT_PATTERNS) {
            val m = pattern.find(normalized)
            if (m != null) {
                val rawAmt = m.groupValues[1].replace(",", "")
                val value = rawAmt.toDoubleOrNull()
                if (value != null && value > 0.0) {
                    parsedAmount = value
                    break
                }
            }
        }
        val amount = parsedAmount ?: return null

        // 4. Extract Sender Number (if present in SMS/Notification)
        var senderNumber = ""
        for (sPattern in SENDER_PATTERNS) {
            val sm = sPattern.find(normalized)
            if (sm != null) {
                // Take only the phone token before any trailing words/spaces
                val rawCandidate = sm.groupValues[1].trim().split(Regex("\\s+")).firstOrNull().orEmpty()
                val candidate = normalizeSenderPreservingMask(rawCandidate)
                if (candidate.startsWith("01") && candidate.length in 9..12) {
                    senderNumber = candidate
                    break
                }
            }
        }

        val hash = sha256("${method.id}|$txIdNormalized|$amount|$senderNumber")

        return ParsedPayment(
            method = method,
            amount = amount,
            txIdNormalized = txIdNormalized,
            senderNumber = senderNumber,
            sourceType = sourceType,
            messageHash = hash
        )
    }

    /**
     * Check compatibility between user-entered senderNumber and SMS-extracted senderNumber.
     * Supports:
     * - Bengali digits (০১৭...) and +8801... on BOTH sides
     * - 11-digit BD numbers & 10-digit missing-leading-zero user input
     * - 12-digit Rocket account numbers (017123456789 <-> 01712345678)
     * - Masked MFS numbers of variable mask length (017***5678, 017****5678, 017XXXX678)
     * - Push notifications that omit sender number (allowed ONLY when TrxID + Amount + Method match)
     */
    fun isSenderCompatible(userSenderRaw: String?, smsSenderRaw: String?): Boolean {
        if (userSenderRaw.isNullOrBlank() || smsSenderRaw.isNullOrBlank()) return true
        val sms = normalizeSenderPreservingMask(smsSenderRaw)
        if (sms.length < 4) return true // Push notification did not carry sender digits

        var user = normalizeSenderPreservingMask(userSenderRaw).filter { it.isDigit() }
        if (user.length == 10 && user.startsWith("1")) {
            user = "0$user"
        }
        if (user.length < 11) {
            // User entered partial digits or last 4-8 digits
            if (user.length in 4..10) {
                return sms.endsWith(user) || user.endsWith(sms.takeLast(4))
            }
            return true
        }

        if (sms.contains("*") || sms.contains("X")) {
            val prefixDigits = sms.takeWhile { it.isDigit() }
            val suffixDigits = sms.takeLastWhile { it.isDigit() }
            if (prefixDigits.length < 2 || suffixDigits.length < 2 || (prefixDigits.length + suffixDigits.length) < 4) {
                return user.endsWith(suffixDigits)
            }
            val prefixOk = user.startsWith(prefixDigits)
            val suffixOk = user.endsWith(suffixDigits) ||
                // Rocket 12-digit check digit tolerance on masked numbers
                (user.length == 11 && sms.length >= 12 && suffixDigits.length >= 3 && user.endsWith(suffixDigits.dropLast(1)))
            return prefixOk && suffixOk
        }

        val smsDigits = sms.filter { it.isDigit() }
        if (smsDigits == user) return true
        if (smsDigits.length == 12 && user.length == 11 && smsDigits.startsWith(user)) return true
        if (user.length == 12 && smsDigits.length == 11 && user.startsWith(smsDigits)) return true
        if (smsDigits.length >= 10 && user.length >= 10 && (smsDigits.endsWith(user.takeLast(8)) || user.endsWith(smsDigits.takeLast(8)))) return true

        return false
    }

    fun isExactAmountMatch(requestedAmount: Double, receivedAmount: Double): Boolean {
        return requestedAmount > 0.0 && receivedAmount > 0.0 && abs(requestedAmount - receivedAmount) < 0.01
    }

    fun convertBengaliDigits(input: String): String {
        val sb = StringBuilder(input.length)
        for (ch in input) {
            when (ch) {
                in '০'..'৯' -> sb.append(('0'.code + (ch.code - '০'.code)).toChar())
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun normalizeBengaliText(input: String): String {
        return convertBengaliDigits(input)
            .replace("\u09af\u09bc", "\u09df") // য + ় -> য়
            .replace("\u09a1\u09bc", "\u09dc") // ড + ় -> ড়
            .replace("\u09a2\u09bc", "\u09dd") // ঢ + ় -> ঢ়
            .replace(Regex("[\\u200B-\\u200F\\uFEFF]"), "")
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
