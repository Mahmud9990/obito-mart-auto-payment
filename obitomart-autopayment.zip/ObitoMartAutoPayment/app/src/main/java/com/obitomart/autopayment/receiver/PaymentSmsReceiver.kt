package com.obitomart.autopayment.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import com.obitomart.autopayment.ObitoBroadcasts
import com.obitomart.autopayment.data.AutoPaymentPrefs
import com.obitomart.autopayment.data.MysqlAutoPaymentRepository
import com.obitomart.autopayment.parser.PaymentMessageParser
import com.obitomart.autopayment.service.AutoPaymentMonitorService
import java.util.concurrent.Executors

/**
 * Receives incoming SMS broadcasts ONLY when Admin has explicitly granted consent,
 * enabled active monitoring, and granted runtime SMS permission.
 */
class PaymentSmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        val ctx = context?.applicationContext ?: return
        if (intent?.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val prefs = AutoPaymentPrefs(ctx)
        if (!prefs.hasAcceptedConsent || !prefs.isMonitoringEnabled) {
            return
        }

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isNullOrEmpty()) return

        val groupedBySender = LinkedHashMap<String, StringBuilder>()
        for (sms in messages) {
            val sender = sms.displayOriginatingAddress ?: sms.originatingAddress ?: continue
            val bodyPart = sms.displayMessageBody ?: sms.messageBody ?: continue
            val isMfsSender = PaymentMessageParser.detectMethodFromSender(sender) != null
            val hasMfsBody = PaymentMessageParser.hasMfsSignature(bodyPart)
            if (!isMfsSender && !hasMfsBody) {
                continue
            }
            groupedBySender.getOrPut(sender) { StringBuilder() }.append(bodyPart)
        }

        if (groupedBySender.isEmpty()) return

        val pendingResult = goAsync()
        WORKER.execute {
            try {
                val repo = MysqlAutoPaymentRepository(ctx)
                var needsRapidFollowUp = false
                for ((sender, fullBodyBuilder) in groupedBySender) {
                    val parsed = PaymentMessageParser.parseSms(sender, fullBodyBuilder.toString())
                    if (parsed == null) {
                        prefs.appendDiagnostic(
                            "INFO",
                            "SMS_IGNORED_FILTER",
                            "",
                            "Sender '$sender' মেসেজটি ইনকামিং পেমেন্ট ফরম্যাটে নেই (অথবা OTP/Outgoing)।"
                        )
                        continue
                    }

                    val alreadyHandled = synchronized(LOCK) {
                        if (prefs.hasProcessedHashRecently(parsed.messageHash)) {
                            true
                        } else {
                            prefs.markHashProcessed(parsed.messageHash)
                            false
                        }
                    }
                    if (alreadyHandled) continue

                    val entry = repo.processIncomingPayment(parsed)
                    ObitoBroadcasts.notifyUiLogUpdated(ctx)
                    ObitoBroadcasts.postApprovedPaymentNotification(ctx, entry)
                    if (entry.statusBadge == "WAITING" || entry.statusBadge == "ERROR") {
                        needsRapidFollowUp = true
                    }
                }

                if (needsRapidFollowUp) {
                    AutoPaymentMonitorService.triggerRapidReconcile(ctx)
                } else {
                    AutoPaymentMonitorService.start(ctx)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }

    companion object {
        private val LOCK = Any()
        private val WORKER = Executors.newSingleThreadExecutor()
    }
}
