package com.obitomart.autopayment

import com.obitomart.autopayment.model.PaymentMethod
import com.obitomart.autopayment.parser.PaymentMessageParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PaymentMessageParserTest {

    @Test
    fun parsesBkashSendMoneyReceivedSms() {
        val sms = "You have received Tk 1,250.00 from 01712345678. Fee Tk 0.00. Balance Tk 5,420.50. TrxID BI8291KLMN at 04/11/2026 14:22"
        val parsed = PaymentMessageParser.parseSms("bKash", sms)
        assertNotNull(parsed)
        assertEquals(PaymentMethod.BKASH, parsed!!.method)
        assertEquals(1250.00, parsed.amount, 0.001)
        assertEquals("BI8291KLMN", parsed.txIdNormalized)
        assertEquals("01712345678", parsed.senderNumber)
    }

    @Test
    fun parsesBkashCashInSms() {
        val sms = "Cash In Tk 500.00 from 01898765432 successful. Fee Tk 0.00. Balance Tk 950.00. TrxID BK7712ABCD at 04/11/2026 18:10"
        val parsed = PaymentMessageParser.parseSms("16247", sms)
        assertNotNull(parsed)
        assertEquals(PaymentMethod.BKASH, parsed!!.method)
        assertEquals(500.00, parsed.amount, 0.001)
        assertEquals("BK7712ABCD", parsed.txIdNormalized)
        assertEquals("01898765432", parsed.senderNumber)
    }

    @Test
    fun parsesNagadMoneyReceivedSms() {
        val sms = "Money Received. Amount: Tk 750.00. Sender: 01911223344. Ref: OBITO. TxnID: 72N98K1L. Balance: Tk 3,200.00. 04/11/2026 15:05"
        val parsed = PaymentMessageParser.parseSms("NAGAD", sms)
        assertNotNull(parsed)
        assertEquals(PaymentMethod.NAGAD, parsed!!.method)
        assertEquals(750.00, parsed.amount, 0.001)
        assertEquals("72N98K1L", parsed.txIdNormalized)
        assertEquals("01911223344", parsed.senderNumber)
    }

    @Test
    fun parsesNagadAmountLabelWithTkBeforeAmount() {
        val sms = "Money Received. Amount: Tk 750.00. Sender: 01911223344. TxnID: 72N98K1L."
        val parsed = PaymentMessageParser.parseSms("NAGAD", sms)
        assertNotNull(parsed)
        assertEquals(PaymentMethod.NAGAD, parsed!!.method)
        assertEquals(750.00, parsed.amount, 0.001)
        assertEquals("72N98K1L", parsed.txIdNormalized)
    }

    @Test
    fun parsesRocketCashIn12DigitAccountSms() {
        val sms = "Cash-In Tk 300.00 from A/C:017123456789 Fee Tk 0.00 Bal Tk 1,800.00 TxnId:4829103847 Date:04-NOV-26 03:20:11 pm"
        val parsed = PaymentMessageParser.parseSms("16216", sms)
        assertNotNull(parsed)
        assertEquals(PaymentMethod.ROCKET, parsed!!.method)
        assertEquals(300.00, parsed.amount, 0.001)
        assertEquals("4829103847", parsed.txIdNormalized)
        assertEquals("017123456789", parsed.senderNumber)
        // User entering 11-digit mobile number matches 12-digit Rocket account
        assertTrue(PaymentMessageParser.isSenderCompatible("01712345678", parsed.senderNumber))
    }

    @Test
    fun parsesBengaliBkashAppNotification() {
        val parsed = PaymentMessageParser.parseNotification(
            packageName = "com.bKash.customerapp",
            title = "বিকাশ পেমেন্ট",
            text = "আপনি ০১৭১২৩৪৫৬৭৮ থেকে ৳৬৫০.০০ পেয়েছেন। ব্যালেন্স ৳২,১০০.০০। TrxID BN9910XYZA"
        )
        assertNotNull(parsed)
        assertEquals(PaymentMethod.BKASH, parsed!!.method)
        assertEquals(650.00, parsed.amount, 0.001)
        assertEquals("BN9910XYZA", parsed.txIdNormalized)
        assertEquals("01712345678", parsed.senderNumber)
    }

    @Test
    fun blocksOtpPinOutgoingAndPersonalMessages() {
        // 1. MFS OTP must NEVER be parsed
        val otpSms = "Your bKash verification code is 482910. Do not share your OTP or PIN with anyone."
        assertNull(PaymentMessageParser.parseSms("bKash", otpSms))

        // 2. Outgoing Send Money must NEVER be parsed as incoming Add Money
        val outgoingSms = "Send Money Tk 500.00 to 01712345678 successful. Fee Tk 5.00. TrxID BO11223344."
        assertNull(PaymentMessageParser.parseSms("bKash", outgoingSms))

        // 3. Personal sender number pretending to send fake SMS must be ignored
        val fakePersonalSms = "You have received Tk 500.00 from 01712345678. TrxID FAKE123456"
        assertNull(PaymentMessageParser.parseSms("+8801799998888", fakePersonalSms))

        // 4. WhatsApp / Messenger notifications must be rejected at package gate
        assertFalse(PaymentMessageParser.isEligibleNotificationPackage("com.whatsapp", "bKash"))
        assertNull(PaymentMessageParser.parseNotification("com.whatsapp", "bKash", fakePersonalSms))
    }

    @Test
    fun parsesExactUserReported20TakaDk451vvzydCase() {
        val bnSms = "আপনি ০১৭১২৩৪৫৬৭৮ থেকে ৳২০.০০ পেয়েছেন। ফি ৳০.০০। ব্যালেন্স ৳৫২০.০০। TrxID DK451VVZYD at 04/11/2026 14:22"
        val parsed = PaymentMessageParser.parseSms("bKash", bnSms)
        assertNotNull(parsed)
        assertEquals(PaymentMethod.BKASH, parsed!!.method)
        assertEquals(20.00, parsed.amount, 0.001)
        assertEquals("DK451VVZYD", parsed.txIdNormalized)
        assertEquals("01712345678", parsed.senderNumber)

        // Even if user pasted "TrxID: DK451VVZYD" or lowercase with spaces on index.html
        assertEquals("DK451VVZYD", PaymentMessageParser.normalizeTrxId("TrxID: DK451VVZYD"))
        assertEquals("DK451VVZYD", PaymentMessageParser.normalizeTrxId("dk451vvzyd "))
        assertEquals("DK451VVZYD", PaymentMessageParser.normalizeTrxId(bnSms))
        assertEquals(20.0, PaymentMessageParser.parseFlexibleAmount("৳২০"), 0.001)
    }

    @Test
    fun parsesNagadBanglaSmsWithPostAmountCurrency() {
        val nagadBn = "মানি রিসিভড। পরিমাণ: ২০.০০ টাকা। প্রেরক: ০১৯১১২২৩৩৪৪। ট্রানজেকশন আইডি: DK451VVZYD। ব্যালেন্স: ৫২০.০০ টাকা।"
        val parsed = PaymentMessageParser.parseSms("16167", nagadBn)
        assertNotNull(parsed)
        assertEquals(PaymentMethod.NAGAD, parsed!!.method)
        assertEquals(20.00, parsed!!.amount, 0.001)
        assertEquals("DK451VVZYD", parsed.txIdNormalized)
        assertEquals("01911223344", parsed.senderNumber)
    }

    @Test
    fun verifiesMaskedAndExactSenderCompatibility() {
        assertTrue(PaymentMessageParser.isSenderCompatible("01712345678", "017****5678"))
        assertTrue(PaymentMessageParser.isSenderCompatible("01712345678", "01712****78"))
        assertTrue(PaymentMessageParser.isSenderCompatible("০১৭১২৩৪৫৬৭৮", "01712345678"))
        assertTrue(PaymentMessageParser.isSenderCompatible("+8801712345678", "01712345678"))
        assertFalse(PaymentMessageParser.isSenderCompatible("01812345678", "01712345678"))
        assertFalse(PaymentMessageParser.isExactAmountMatch(500.0, 490.0))
        assertTrue(PaymentMessageParser.isExactAmountMatch(20.0, 20.0))
    }
}
