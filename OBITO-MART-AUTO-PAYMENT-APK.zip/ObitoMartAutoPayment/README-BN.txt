OBITO MART AUTO PAYMENT SYSTEM — ANDROID SOURCE ONLY
Version: 1.1.0

এই ZIP-এ শুধু Android Studio Project রাখা হয়েছে। Website/PHP ফাইল এতে নেই।

প্রধান বৈশিষ্ট্য:
- Activation Key ও device registration
- bKash, Nagad ও Rocket incoming payment SMS/notification parsing
- MySQL-backed HTTPS API: https://obitomart.gamer.gd/api/autopay/
- Payment history, diagnostics, settings এবং dashboard metrics
- Professional dark navy + electric-blue UI polish

UI আপডেটে layout-এর বিদ্যমান View ID ও Activity logic অক্ষত রাখার চেষ্টা করা হয়েছে।
অ্যাপের payment/SMS behavior বা backend protocol ইচ্ছাকৃতভাবে বদলানো হয়নি।

Build:
1. Android Studio-তে এই project folder open করুন।
2. Gradle sync শেষ করুন।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।

নোট:
- এই ZIP source project; prebuilt APK নয়।
- বাস্তব bKash/Nagad/Rocket SMS, device permissions, backend matching এবং duplicate transaction test এখানে চালানো হয়নি।
- live customer payment চালুর আগে নিজের নিয়ন্ত্রিত ছোট test transaction দিয়ে পরীক্ষা করুন।
- SMS/Notification access শুধুমাত্র অনুমোদিত admin device-এ, ব্যবহারকারীর স্পষ্ট সম্মতিতে দিন।


VERSION 1.1.1 DIAGNOSTIC UPDATE
- Android API client now detects non-JSON/HTML responses safely and displays HTTP status, Content-Type and a short sanitized response preview.
- Redirects are not silently followed, so hosting redirect/WAF errors can be identified.
- API_BASE remains https://obitomart.gamer.gd/api/autopay/.
- No Firebase or additional third-party account/service is required for this PHP/MySQL build.
